# Nasim Mahmud Mishu · Portfolio

Personal academic portfolio website. Pure **HTML5 + CSS3 + TypeScript** (compiled to
plain vanilla JavaScript). No frameworks, no libraries, no build system, no backend.
The only external resource is the JetBrains Mono font from Google Fonts, and the site
still works without it (falls back to a system monospace).

This README is the maintenance guide for the site. You do not need to be a web
developer to keep it updated: almost everything is plain HTML text you can edit in
any text editor. Each common task below is a numbered step-by-step recipe with
copy-paste snippets.

Quick facts:

- **Static**: open `index.html` in a browser and the site just works. No install,
  no server, no build step.
- **GitHub Pages ready**: push the folder to a repository and turn on Pages (see
  section 10).
- **Light mode only**, one stylesheet, one script.
- The HTML pages load `scripts/main.js` (the compiled file). `scripts/main.ts` is
  the readable source; editing it is optional (see sections 4d and 11).

## 1. File map: what each file does

```
.
├── index.html           # home: hero, about, featured projects, news, get in touch
├── research.html        # research interests list
├── experience.html      # experience timeline with tech tags + education
├── projects.html        # full project card grid (cards open the detail modal)
├── publications.html    # publications list (numbered, newest first)
├── contact.html         # contact card with email/github/linkedin
├── css/
│   └── style.css        # ALL styling: colors, fonts, layout, animations
├── scripts/
│   ├── main.ts          # TypeScript source (strict mode); human-readable
│   └── main.js          # compiled output; the file every page actually loads
├── assets/
│   └── img/
│       ├── profile.svg              # placeholder; square portrait
│       ├── project-niro-bot.svg     # placeholder; 640 x 320
│       ├── project-hex.svg          # placeholder; 640 x 320
│       ├── project-aoaver.svg       # placeholder; 640 x 320
│       ├── project-gesture.svg      # placeholder; 640 x 320
│       ├── project-shouhardo.svg    # placeholder; 640 x 320
│       └── favicon.svg              # "N/" monogram shown in the browser tab
├── cv.pdf               # (you add this) the CV the hero links to
└── README.md            # this file
```

Two things to know before editing anything:

1. **The nav bar and footer are duplicated in all six HTML files** (plain static
   site, no templating). If you change the nav or footer, apply the same edit in
   all six pages.
2. **All paths are relative** (`css/style.css`, `assets/img/...`), which is why the
   site works both from `file://` and from GitHub Pages. Keep new paths relative.

## 2. Changing text on any page

All visible text lives directly in the six HTML files as plain, commented HTML.
Sections are marked with banners like `<!-- ================= ABOUT ================= -->`.

General recipe:

1. Open the HTML file for the page in any text editor.
2. Find the section banner, then the text you want to change.
3. Edit the text between the tags. Do not delete the tags themselves
   (`<p>`, `<b>`, `<span>`, `<div>` and so on).
4. Save and reload the page in your browser. Done. No build step.

Examples:

**Hero name and role** (`index.html`):

```html
<h1>Nasim Mahmud Mishu</h1>
<p class="role">
  <b class="hl-g">Research Assistant</b> · NSU Intelligent Robotics (NIRO) Lab<br />
  Dept. of ECE, North South University · Dhaka, Bangladesh
</p>
```

**About paragraphs** (`index.html`, section `ABOUT`): each paragraph is a
`<p class="muted"> ... </p>` block. Edit the sentences inside. `<b>` wraps bold or
highlighted phrases (see section 9 for the highlight classes); `<a href="...">` is
a link.

**News items** (`index.html`, section `NEWS`): see section 3.

**Contact info** (`contact.html` and the `GET IN TOUCH` section of `index.html`):
see section 8.

**Page titles and search descriptions**: the `<title>` and
`<meta name="description" ...>` lines at the top of each HTML file. Optional to
change, but keep them roughly in sync with the page content.

**Footer**: the single `<p class="copy">` line at the bottom of every page. The
year updates itself via JavaScript; leave `<span id="year">` in place.

Small style rules that apply everywhere on the site:

- Use a plain hyphen `-` in date ranges (`Oct 2024 - Present`), never the long
  dash characters.
- `·` (middle dot) is used as a separator in meta lines; copy an existing one if
  you need it.

## 3. Adding or removing a NEWS entry (home page)

News items live in `index.html` inside the `<!-- ===== NEWS ===== -->` section.
Each item is one line:

```html
<div class="news-item"><span class="news-date">[Nov 2025]</span><span class="news-text">Participated in the NSU AI, IoT &amp; Robotics Day, 2025.</span></div>
```

To **add** an entry:

1. Copy an existing `news-item` line.
2. Paste it at the TOP of the list (newest first).
3. Change the date inside `[...]` and the text inside `<span class="news-text">`.

Template:

```html
<div class="news-item"><span class="news-date">[Mon YYYY]</span><span class="news-text">Your news text here.</span></div>
```

To **remove** an entry: delete its whole `<div class="news-item"> ... </div>` line.

Notes:

- `&amp;` is how you write a literal `&` in HTML. Use `&amp;` if your text needs
  an ampersand.
- You may wrap a short phrase in `<b class="hl-p">...</b>` to highlight it (see
  section 9) and add links with `<a href="https://..." target="_blank" rel="noopener noreferrer">link text</a>`.

## 4. Adding a new PROJECT

A project has up to three parts: the card in `projects.html` (required), the
matching detail entry in `scripts/main.ts` (required if the card should open the
modal), and optionally a featured card on `index.html`.

### 4a. The card (`projects.html`)

Cards live inside `<div class="proj-grid">` in `projects.html`. Copy-paste this
template and fill it in:

```html
<article class="proj-card" data-project="my-new-project" tabindex="0" role="button" aria-haspopup="dialog" aria-label="My New Project: open project details">
  <svg class="proj-svg" viewBox="0 0 640 320" role="img" aria-label="My New Project placeholder artwork">
    <rect width="640" height="320" fill="var(--code-bg)" />
    <rect x="6" y="6" width="628" height="308" fill="none" stroke="var(--ink-faint)" stroke-width="1.5" stroke-dasharray="8 6" rx="8" />
    <text x="320" y="284" text-anchor="middle" font-size="14" font-family="JetBrains Mono, monospace" fill="var(--ink-faint)">[ replace: my-new-project.jpg ]</text>
  </svg>
  <div class="proj-body">
    <div class="proj-title"><span class="card-hl">My New Project</span></div>
    <div class="proj-meta">NIRO Lab · Jan 2026 - Present</div>
    <p class="proj-desc">One or two sentences describing the project on the card.</p>
    <div class="proj-tech"><b>→</b> Python · ROS · Raspberry Pi</div>
    <div class="proj-more" aria-hidden="true">details →</div>
  </div>
</article>
```

Field by field:

- `data-project="my-new-project"`: the unique key that links this card to its
  detail entry in `scripts/main.ts`. Pick a short lowercase slug (letters,
  numbers, hyphens). It must match the entry key EXACTLY.
- `aria-label`: repeat the project title for screen readers.
- `<img ...>`: the card image. See section 7 for adding the image file.
- `<span class="card-hl">`: wraps the title so it gets the hover highlight sweep.
  Keep the span; only change the text inside.
- `proj-meta`: the small gray line (lab · dates).
- `proj-desc`: the card teaser. You may highlight one phrase with
  `<span class="hl-y">...</span>` (see section 9).
- `proj-tech`: the tech list after the `<b>→</b>` arrow.

To **feature** the project on the home page: copy the exact same `<article>` block
into the `proj-grid` of `index.html` (section `FEATURED PROJECTS`), replacing one
of the two cards there. Same markup, same `data-project` key; the modal works on
both pages. The home page shows at most two featured cards, so swap rather than
stack.

### 4b. The detail entry (`scripts/main.ts`)

The modal text does NOT live in the HTML. It lives in the `PROJECT_DETAILS` map
near the top of `scripts/main.ts`, keyed by the same `data-project` value. Add a
new entry inside `PROJECT_DETAILS` using this template:

```ts
  "my-new-project": {
    id: "my-new-project",
    title: "My New Project",
    meta: "NIRO Lab · Jan 2026 - Present",
    summary:
      "One short paragraph shown at the top of the modal. " +
      "Continue long strings on the next line like this.",
    highlights: [
      "Bullet point shown under // highlights",
      "Another result or feature",
    ],
    why:
      "A short personal paragraph under // why I built it: the motivation.",
    spotlight: [
      "The hardest technical challenge and how you solved it (// the hard part).",
    ],
    lessons: [
      "What you learned, one bullet per lesson (// what I learned).",
    ],
    tech: ["Python", "ROS", "Raspberry Pi"],
    status: "active development",
    links: [
      { label: "github", url: "https://github.com/Nasim-Mahmud/my-new-project" },
    ],
    keyPhrases: [
      "short phrase copied exactly from the copy above",
      "another exact phrase",
    ],
  },
```

Every field explained:

- `id`: same slug as `data-project`. Must match exactly.
- `title`: heading of the modal.
- `meta`: the small gray line under the title (lab · dates).
- `summary`: opening paragraph of the modal.
- `highlights`: array of bullet strings under the `// highlights` sub-head.
- `why`: paragraph under `// why I built it`.
- `spotlight`: bullets under `// the hard part`.
- `lessons`: bullets under `// what I learned`.
- `tech`: array of short tag strings shown as chips.
- `status`: shown after the `status:` label at the bottom (e.g. `active
  development`, `completed`, `paused`).
- `links`: array of `{ label, url }` pairs shown as outbound links at the bottom.
  Use an empty array `[]` if there are none yet.
- `keyPhrases`: 3 to 6 short phrases that get a marker-highlight sweep inside the
  modal. **RULE: each phrase must match the modal copy EXACTLY** (same words, same
  case, same punctuation), because the script searches the rendered text for these
  literal strings. Copy them character-for-character out of your `summary`, `why`,
  `highlights`, `spotlight`, or `lessons` text. A phrase that does not match
  anything is silently skipped.

### 4c. The artwork (inline animated SVG)

Card artwork is NOT an external file. Each card carries an INLINE
`<svg class="proj-svg" viewBox="0 0 640 320">` block: a warm-gray placeholder
with a dashed frame, a simple geometric robot drawing, a centered
`[ replace: name.jpg ]` label, and one subtle looping animation (blinking eye,
radar sweep, radiating arcs, and so on). The animation is pure CSS (keyframes
in `style.css`, section "ANIMATED SVG PLACEHOLDERS"): it is PAUSED by default
and only plays while the card is hovered or keyboard-focused, or while the
project modal is open (the modal shows a clone of the card's own SVG; see
section 9d). Under `prefers-reduced-motion` the art never moves.

For a new project, copy an existing card's whole `<svg>` block and edit only
the `aria-label` and the label text. Nothing else is needed.

To use a REAL photo or screenshot instead, replace the entire `<svg>` block
with a plain image tag:

```html
<img class="proj-img" src="assets/img/project-my-new-project.jpg" alt="My New Project" width="640" height="320" />
```

Recommended size is 640 x 320 (any 2:1 ratio works). The `.proj-img` styles
(including the hover zoom) are still in `style.css`, and the modal falls back
to showing that image. The old standalone placeholder files still live in
`assets/img/project-*.svg` if you ever want to export or reuse them.

### 4d. Recompiling after editing main.ts

The browser loads `scripts/main.js`, NOT `main.ts`. After editing `main.ts` you
must regenerate `main.js`. Two options:

**Option 1: recompile (recommended).** With any TypeScript 5.x installed
(`npm install -g typescript`, one-time), run from the project root:

```sh
tsc scripts/main.ts --target ES2019 --strict --outFile scripts/main.js
```

**Option 2: no TypeScript install.** `main.js` is plain readable JavaScript and
contains the same `PROJECT_DETAILS` map in almost identical syntax (search for
`PROJECT_DETAILS` in `main.js`). You can add your entry directly there instead,
following the same template. The syntax difference: TypeScript type annotations
like `: string` do not exist in the `.js` file, and object entries look the same
otherwise. If you edit `main.js` by hand, keep `main.ts` in sync later when you
can, or the next recompile would overwrite your change.

## 5. Adding an EXPERIENCE entry

Experience entries live in `experience.html` inside the
`<!-- ===== EXPERIENCE ===== -->` section. The timeline shows the DATE in a left
column, a vertical line with a dot per entry, and the role details on the right
(on phones it collapses to date-above-content with the line at the far left).
Newest entry goes at the TOP. Template:

```html
<div class="xp-item">
  <div class="xp-when"><div class="xp-date">Mon YYYY - Present</div></div>
  <div class="xp-body">
    <div class="xp-role"><b class="hl-g">Role Title</b></div>
    <div class="xp-org">Organization · Place</div>
    <p class="xp-detail">One or two sentences about what you do or did.</p>
    <div class="xp-tags">
      <span class="tag">skill one</span>
      <span class="tag">skill two</span>
    </div>
  </div>
</div>
```

Structure notes:

- `.xp-when` is the left date column; keep it first.
- `.xp-body` wraps everything that sits right of the line: role, org, detail,
  tags. Do not move `.xp-date` out of `.xp-when` or the two-column grid breaks.
- `<b class="hl-g">` around the role title gives it the green highlight sweep
  (see section 9; `hl-y`, `hl-p` also used in existing entries).
- Date ranges use a plain hyphen: `Oct 2024 - Present`, `Dec 2023 - Jun 2024`.
- Tags are free-form lowercase labels, one `<span class="tag">` each.
- Education entries further down the page are simpler `.edu-item` blocks with
  `.edu-deg` and `.edu-meta` lines; copy the existing block to add one.

## 6. Adding a PUBLICATION

Publications live in `publications.html`, numbered with the NEWEST first
(descending year order). Template:

```html
<div class="pub">
  <div><span class="pub-num">[1]</span><span class="pub-title">Full Paper Title</span></div>
  <div class="pub-venue">Venue Name YYYY · extra venue detail</div>
  <div class="pub-id"><a href="https://doi.org/..." target="_blank" rel="noopener noreferrer">doi:... ↗</a></div>
</div>
```

Steps:

1. Paste the new block at the TOP of the publications section.
2. Renumber ALL entries so the new one is `[1]`, the previous first becomes
   `[2]`, and so on down the list.
3. If the DOI or link is not available yet, use
   `<a href="#" title="DOI pending: link coming soon">doi ↗</a>` like the
   existing pending entry, and replace the `href` later.

## 7. Replacing placeholder images and the profile photo

Every image is an intentional placeholder (warm gray, dashed border) showing
which real file to drop in. The profile photo and favicon are placeholder SVG
FILES; project card art is an inline animated SVG block inside the card markup
(see section 4c).

- **Profile photo**: replace `assets/img/profile.svg` with a square portrait,
  ideally 352 x 352 px or larger (it displays at 176px on desktop, 128px on
  phones). If you use a `.jpg` or `.png`, name it `profile.jpg` (etc.) and update
  the single `src="assets/img/profile.svg"` reference in the hero of
  `index.html`. The photo is static (no click or zoom behavior).
- **Project artwork**: the cards do not load image files; each card has an
  inline animated SVG placeholder (see section 4c). To use a real screenshot,
  drop the file in `assets/img/` (ideally 640 x 320 or any 2:1 ratio) and swap
  the card's whole `<svg class="proj-svg"> ... </svg>` block for
  `<img class="proj-img" src="assets/img/your-file.jpg" alt="..." width="640" height="320" />`
  in `projects.html` (and in `index.html` if the project is featured there).
  The modal automatically shows whatever art the card carries: it clones the
  inline SVG (animations keep playing while the modal is open) or falls back
  to the `<img>`. The `assets/img/project-*.svg` files remain on disk as
  exportable placeholders but are no longer referenced by the pages.
- **Favicon**: replace `assets/img/favicon.svg` if desired; every page references
  it in the `<head>`.

## 8. Updating email / github / linkedin / cv links

The same four links appear in three places; update all of them:

1. Hero links in `index.html` (section `HERO`, the `.hero-links` block).
2. Get-in-touch links in `index.html` (section `GET IN TOUCH`).
3. The contact card in `contact.html`.

```html
<a href="mailto:you@example.com">email</a>
<a href="https://github.com/yourname" target="_blank" rel="noopener noreferrer">github</a>
<a href="https://www.linkedin.com/in/yourname/" target="_blank" rel="noopener noreferrer">linkedin</a>
<a href="cv.pdf">cv.pdf</a>
```

**CV**: the hero links to `cv.pdf`. Put your CV file named exactly `cv.pdf` in the
repository root (next to `index.html`) and the link works as-is.

## 9. Customizing the highlight system

Marker-style highlights run across the site: cyan sweeps on section headings and
card titles, and colored highlights on informative phrases. All colors come from
one palette system. Keyword phrase highlights are SCROLL-TRIGGERED: each phrase
sweeps in once when it scrolls into view and stays highlighted (section 9b).
The only hover-triggered highlights are on project cards: the card title and
the card teaser keywords sweep while the card is hovered or keyboard-focused,
together with the animated card art. Modal phrases sweep when the modal opens.

### 9a. The four random palettes

Near the top of `scripts/main.ts` there is a `HIGHLIGHT_PALETTES` array with four
entries. On EVERY page load one palette is picked at random (an immediate repeat
of the last palette in the same tab is re-rolled). Each palette defines five
colors:

- `colorA`: yellow family, used by `.hl-y` (research topics, technical concepts)
- `colorB`: green family, used by `.hl-g` (roles, affiliations, memberships)
- `colorC`: peach family, used by `.hl-p` (calls to action, achievements)
- `colorD`: dusty blue / violet-gray family, used by `.hl-b` (extra chunks of
  long phrases, so multi-part phrases can vary in color)
- `headCyan`: the cyan highlighter shared by section-heading words
  (`.sec-word`), project card titles (`.card-hl`), and modal sub-heads

To **edit colors**: change the rgba values inside one palette entry (or add a
fifth entry to the array) and recompile `main.ts` (section 4d), or edit the same
array in `main.js` directly. Keep the colors muted and flat (alpha roughly
.45-.9), keep hues out of the pink/magenta band, keep `colorD` clear of the cyan
heading tint, and keep `headCyan` in the cyan band (hue ~180-200). The fallback
colors shown without JavaScript live in `css/style.css` under `:root`
(`--hl-y`, `--hl-g`, `--hl-p`, `--hl-b`, `--hl-head`); update those too if you
change the classic palette.

### 9b. Adding or removing a highlighted phrase

Any phrase in any page can be highlighted by wrapping it in a `<b>` or `<span>`
with one of the variant classes:

```html
<b class="hl-y">swarm robotics</b>        <!-- yellow: topics, concepts -->
<b class="hl-g">Research Assistant</b>    <!-- green: roles, affiliations -->
<b class="hl-p">open to research collaborations</b>  <!-- peach: calls to action -->
<span class="hl-b">deep reinforcement learning</span> <!-- dusty blue: extra chunks -->
```

The sweep plays automatically, exactly once, when the phrase scrolls into view
(`initHighlights` in `scripts/main.ts` adds the `.hl` / `.hl-on` classes at
runtime; with JS off the `<b>` just renders bold). Once lit, a phrase stays
lit. Above-the-fold phrases (the hero role on the home page) sweep on page
entry. The trigger for every location:

| Where the phrase lives | What triggers the sweep |
| --- | --- |
| About paragraphs (`index.html`) | scrolling the paragraph into view |
| Hero role line (`index.html`) | page entry (already above the fold) |
| News entries (`index.html`) | scrolling the news row into view |
| Research interests (`research.html`) | scrolling the list into view |
| Experience roles (`experience.html`) | scrolling the entry into view |
| Project card teasers (`projects.html`) | HOVER / keyboard-focus on the card (sweeps together with the title; reverts when the pointer leaves) |

Project card teaser keywords are the ONLY hover-triggered keyword highlights
on the site: `initHighlights` deliberately skips everything inside
`.proj-desc`, and the `.proj-card:hover .proj-desc ...` rule in
`css/style.css` ("KEYWORD MARKER HIGHLIGHTS") owns them instead. Any new
highlighted phrase outside a card teaser gets the scroll-triggered sweep
automatically, no extra CSS needed. To REMOVE a highlight, unwrap the text
(delete the `<b ...>` and `</b>` tags, keep the text). The highlight alone
carries the emphasis, so highlighted words are intentionally not
bold-weight.

Heading words are highlighted differently: wrap the word in
`<span class="sec-word">...</span>` inside an `<h1>`/`<h2>` with class
`sec-head`, as in every existing section heading.

### 9c. Modal key phrases

The phrases highlighted inside a project modal come from that project's
`keyPhrases` array in `PROJECT_DETAILS` (section 4b). They must match the modal
copy EXACTLY (case-sensitive). Edit the array and recompile, or edit `main.js`.

### 9d. Card artwork and the modal

Each project card's artwork is an inline `<svg class="proj-svg">` (section 4c).
When a card opens, the modal CLONES that SVG into the dialog as
`<svg class="modal-svg playing">`; the `.playing` class is what lets the CSS
animation loops run while the modal is open. Closing the modal discards the
clone, so the card art goes back to its paused resting state unless the card
is still hovered. If you swapped the card art for a real
`<img class="proj-img">` photo, the modal shows that image instead
(`.modal-img`). All of this is handled by `buildModalContent` in
`scripts/main.ts`; there is nothing to configure.

## 10. Deploying to GitHub Pages and previewing locally

### Preview locally

- Simplest: double-click `index.html`. Everything works from `file://`.
- Nicer (avoids any browser file restrictions): run a tiny local server from the
  project folder and open `http://localhost:8000`:

```sh
python3 -m http.server 8000
```

### Deploy (GitHub Pages)

**Option A: project site.**

1. Push this folder's contents to a GitHub repository (e.g. `portfolio`).
2. In the repo: **Settings > Pages > Build and deployment > Deploy from a branch**.
3. Choose the `main` branch and the `/ (root)` folder, then save.
4. The site goes live at `https://<username>.github.io/<repo>/`.

**Option B: user site.**

1. Create a repository named `<username>.github.io`.
2. Push these files to its root. The site is served at `https://<username>.github.io/`.

### Custom domain (optional)

A `yourname.com` (or `.dev` / `.me`) address looks better on a CV than the
default `github.io` URL. Buy the domain from any registrar, add a plain file
named `CNAME` to the repository root containing only the domain (e.g.
`nasimmahmud.com`), point the registrar's DNS at GitHub (an `A` record to the
GitHub Pages IPs, or a `CNAME` record to `<username>.github.io` for a
subdomain), and enable the domain under **Settings > Pages > Custom domain**.

## 11. Reference: what main.js actually does

You never need to touch this for content edits, but for orientation
`scripts/main.js` provides:

- page transitions (entry/exit fade, bfcache restore; internal `.html` link
  clicks are intercepted and animated)
- the random highlight palette roll per page load (section 9)
- the current-page nav marker (`▸` plus `aria-current="page"`)
- the mobile hamburger menu
- reveal-on-scroll animations and the staggered hero entrance on `index.html`
- scroll-triggered keyword highlights (`.hl` / `.hl-on` classes; one-shot,
  phrases stay lit once revealed)
- the project detail modal on `projects.html` and `index.html` (backdrop click,
  ESC, or close button to dismiss; focus returns to the originating card;
  the card's artwork, an inline animated SVG or a real photo, is cloned into
  the dialog)
- the automatic footer year

Only the project-card interactions (title + teaser keyword sweeps, SVG
placeholder animations) are pure CSS hover/focus effects and need no
JavaScript. All animations are disabled under `prefers-reduced-motion`:
scroll highlights apply instantly, the SVG art never moves, and navigation
happens without fades. Every page starts with a
visually hidden "skip to content" link for keyboard users.

If you ever edit `scripts/main.ts`, recompile with:

```sh
tsc scripts/main.ts --target ES2019 --strict --outFile scripts/main.js
```

(Requires any TypeScript 5.x install: `npm install -g typescript`. This is local
tooling only; nothing npm-related is part of the website itself.)
