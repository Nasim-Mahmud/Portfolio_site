/* ==========================================================================
   Nasim Mahmud Mishu · portfolio
   main.ts · typed TypeScript source (strict mode, no external deps)

   Compile (the compiled main.js is what the site loads):
     tsc scripts/main.ts --target ES2019 --strict --outFile scripts/main.js
   ========================================================================== */

/* ---------------------------------------------------------------- types -- */

interface ObserverConfig {
  root: Element | Document | null;
  rootMargin: string;
  threshold: number | number[];
}

/* one set of flat paper-marker highlight colors */
interface PaletteColors {
  colorA: string;   /* yellow family (.hl-y): research topics + modal phrases */
  colorB: string;   /* green family (.hl-g): roles, affiliations + modal phrases */
  colorC: string;   /* peach family (.hl-p): call to action + modal phrases */
  colorD: string;   /* dusty blue / violet-gray family (.hl-b): extra chunks of long phrases */
  headCyan: string; /* cyan highlighter: section headings, card titles, modal sub-heads */
}

interface HighlightPalette {
  name: string;
  colors: PaletteColors;
}

interface ProjectLink {
  label: string;
  url: string;
}

interface ProjectDetail {
  id: string;
  title: string;
  meta: string;
  summary: string;
  highlights: string[];
  why: string;
  spotlight: string[];
  lessons: string[];
  tech: string[];
  status: string;
  links: ProjectLink[];
  /* short phrases copied EXACTLY from this project's summary/why/highlights/
     spotlight/lessons copy; the first occurrence of each inside the modal
     gets a .modal-hl marker sweep when the modal opens */
  keyPhrases: string[];
}

/* ------------------------------------------------------------ constants -- */

const REVEAL_OPTIONS: ObserverConfig = {
  root: null,
  rootMargin: "0px 0px -8% 0px",
  threshold: 0.05,
};

/* keyword highlights use the same viewport band as section reveals: a
   phrase sweeps in once it sits ~8% above the bottom edge and ~5% of it
   is visible */
const HIGHLIGHT_OPTIONS: ObserverConfig = {
  root: null,
  rootMargin: "0px 0px -8% 0px",
  threshold: 0.05,
};

/* ------------------------------------------------------ highlight palettes --
   Four curated palettes; one is rolled at random on every full page load.
   All are muted, flat paper-marker colors (the site is light-mode only).
   colorA/colorB/colorC/colorD are the four content highlight colors
   (.hl-y/.hl-g/.hl-p/.hl-b and the modal key-phrase variants); colorD is a
   dusty blue / soft violet-gray used to give the chunks of a long phrase
   distinct colors, and its hue stays well clear of the cyan heading tint.
   headCyan is the cyan highlighter shared by section-heading words, project
   card titles, and modal sub-heads (hue ~190, alpha ~.45-.6, a slightly
   different cyan per palette).
   No pink/rose/magenta hues anywhere. To add or edit a palette, extend
   HIGHLIGHT_PALETTES below; no other code changes are needed. */

const PALETTE_STORAGE_KEY: string = "portfolio-palette-idx";

const HIGHLIGHT_PALETTES: HighlightPalette[] = [
  {
    name: "classic",
    colors: {
      colorA: "rgba(255, 214, 96, .9)",    /* marker yellow */
      colorB: "rgba(157, 191, 158, .68)",  /* sage green */
      colorC: "rgba(242, 184, 128, .62)",  /* soft peach */
      colorD: "rgba(158, 155, 210, .62)",  /* soft violet-gray */
      headCyan: "rgba(94, 190, 210, .55)", /* flat cyan */
    },
  },
  {
    name: "citrus",
    colors: {
      colorA: "rgba(250, 230, 90, .85)",   /* lemon */
      colorB: "rgba(140, 215, 175, .6)",   /* mint */
      colorC: "rgba(245, 165, 80, .62)",   /* tangerine */
      colorD: "rgba(150, 152, 214, .62)",  /* periwinkle */
      headCyan: "rgba(72, 178, 206, .5)",  /* deep cyan */
    },
  },
  {
    name: "golden",
    colors: {
      colorA: "rgba(245, 190, 70, .85)",   /* amber */
      colorB: "rgba(178, 188, 105, .6)",   /* olive green */
      colorC: "rgba(240, 175, 120, .62)",  /* apricot */
      colorD: "rgba(170, 148, 198, .6)",   /* dusty mauve-violet */
      headCyan: "rgba(110, 198, 218, .58)",/* light cyan */
    },
  },
  {
    name: "fresh",
    colors: {
      colorA: "rgba(235, 210, 110, .85)",  /* pale gold */
      colorB: "rgba(110, 190, 170, .6)",   /* teal-green */
      colorC: "rgba(245, 155, 95, .62)",   /* mandarin */
      colorD: "rgba(148, 160, 208, .62)",  /* dusty steel blue */
      headCyan: "rgba(88, 186, 214, .48)", /* soft cyan */
    },
  },
];

/* matches the .2s open/close transitions in style.css */
const ANIMATION_MS: number = 200;

/* page transition timings: entry fade is .25s, exit fade is .18s */
const EXIT_ANIMATION_MS: number = 180;

/* stagger between hero elements on the home-page entrance */
const HERO_STAGGER_MS: number = 60;

/* small stagger between elements that sweep in during the same frame
   (keyword highlights and section-heading words) */
const HIGHLIGHT_STAGGER_MS: number = 120;

/* stagger between the modal sub-head/key-phrase sweeps when a modal opens */
const MODAL_SWEEP_STAGGER_MS: number = 80;

/* page-heading sweep: the first .sec-head word lights up shortly after the
   page-entry transition begins (entry fade is .25s) */
const HEADING_SWEEP_DELAY_MS: number = 120;

/* --------------------------------------------------- project detail data --
   Content for the project modal lives here, keyed by the data-project
   attribute on each card in projects.html. Edit a project's text, highlights,
   tech tags, status, or links below; the card grid itself stays untouched. */

const PROJECT_DETAILS: Record<string, ProjectDetail> = {
  "niro-bot": {
    id: "niro-bot",
    title: "NIRO Educational Bot",
    meta: "NIRO Lab · Oct 2024 - Present",
    summary:
      "An educational robot built at the NSU Intelligent Robotics (NIRO) Lab to support hands-on learning and research. " +
      "A Raspberry Pi and an Arduino share the processing over WiFi, on a 3D-printed chassis with a custom PCB and a " +
      "differential drive system. The design leaves room for hardware extensions such as LiDAR and depth cameras.",
    highlights: [
      "Gyroscope, IR sensors, motors, and WiFi integrated with Raspberry Pi and Arduino",
      "Custom 3D-printed chassis and PCB with a differential drive system",
      "Hardware extensions for LiDAR and depth cameras",
      "Shown as a top-ranked robotics demo at BEAR Summit 2025, Dhaka",
    ],
    why:
      "Robotics students learn faster with hardware they can open, modify, and break without fear. " +
      "The lab needed an affordable platform for teaching and research, and the ready-made kits were " +
      "either too expensive or too closed. So we built our own.",
    spotlight: [
      "Fitting the gyroscope, IR sensors, motors, and WiFi onto a custom PCB while keeping it cheap enough for anyone to reproduce.",
      "Designing the 3D-printed chassis so LiDAR and depth cameras can be added later without redesigning the robot.",
    ],
    lessons: [
      "PCB design and fabrication basics, learned by doing rather than reading.",
      "Writing documentation good enough that other students can rebuild the bot on their own.",
      "Demoing at BEAR Summit 2025 taught me to explain hardware to non-hardware people.",
    ],
    tech: ["Raspberry Pi", "Arduino", "3D Printing", "PCB Design"],
    status: "ongoing",
    links: [],
    keyPhrases: [
      "educational robot",
      "Raspberry Pi",
      "3D-printed chassis",
      "differential drive system",
      "LiDAR and depth cameras",
      "BEAR Summit 2025",
    ],
  },
  "project-hex": {
    id: "project-hex",
    title: "Project Hex",
    meta: "NIRO Lab · Feb 2025 - Present",
    summary:
      "A hexapod robot built for mobility on uneven terrain, where wheeled robots struggle. Six 3-DOF legs driven by " +
      "18 high-torque bus servos give it stable locomotion, with an Arduino handling real-time control. A LiPo battery " +
      "powers extended runs, and modular mounts accept a Raspberry Pi, LiDAR, and depth sensors.",
    highlights: [
      "Six legs with 3 DOF each for stability on uneven terrain",
      "18 high-torque bus servos, LiPo powered for extended operation",
      "Arduino-based real-time control",
      "Modular mounts for Raspberry Pi, LiDAR, and depth sensors",
    ],
    why:
      "Wheeled robots struggle on rough terrain, and I wanted to understand legged locomotion hands-on. " +
      "Building a hexapod forces you to think about stability and control in a way wheels never do.",
    spotlight: [
      "Coordinating 18 bus servos in real time from an Arduino without jitter, and sequencing stable gaits for six 3-DOF legs.",
      "Power draw from 18 servos forced careful LiPo and wiring decisions; a brownout can reset the controller mid-step.",
    ],
    lessons: [
      "Gait timing is a control problem, not just a mechanical one.",
      "Modular mounts paid off when adding sensors later; no redesign needed.",
    ],
    tech: ["Arduino", "Servo Control", "LiPo", "Modular Design"],
    status: "ongoing",
    links: [],
    keyPhrases: [
      "hexapod robot",
      "uneven terrain",
      "18 high-torque bus servos",
      "real-time control",
      "3-DOF legs",
    ],
  },
  aoaver: {
    id: "aoaver",
    title: "AOAVER: Autonomous Obstacle Avoiding Exploring Robot",
    meta: "Capstone (CSE499) · 2021 - 2022",
    summary:
      "My B.Sc. capstone project: an autonomous search-and-rescue robot for disaster-prone areas, where sending people " +
      "in is risky. It combines obstacle avoidance and exploration algorithms with real-time perception from a LiDAR, " +
      "running ROS on Linux.",
    highlights: [
      "Obstacle avoidance and exploration algorithms for hazardous environments",
      "YDLidar X4 with Raspberry Pi 3B+ and Arduino UNO",
      "ROS on Linux for real-time perception and decision-making",
      "Completed as my undergraduate thesis project",
    ],
    why:
      "Bangladesh is disaster-prone, and sending people into unstable buildings to search is dangerous. " +
      "An exploring robot that maps and avoids obstacles on its own felt worth a year of work. This was " +
      "my B.Sc. thesis.",
    spotlight: [
      "Getting the YDLidar X4, Raspberry Pi 3B+, and Arduino UNO to cooperate under ROS on Linux while running obstacle avoidance in real time.",
    ],
    lessons: [
      "ROS and Linux systems work: nodes, topics, and a lot of debugging.",
      "How to scope a year-long thesis and actually finish it.",
      "Defending the work taught me to present technical decisions clearly.",
    ],
    tech: ["Python", "ROS", "YDLidar X4", "Raspberry Pi", "Arduino"],
    status: "completed 2022",
    links: [],
    keyPhrases: [
      "autonomous search-and-rescue robot",
      "obstacle avoidance",
      "ROS on Linux",
      "YDLidar X4",
      "undergraduate thesis",
    ],
  },
  gesture: {
    id: "gesture",
    title: "Hand Gesture Recognition for Seniors & Disabled",
    meta: "Junior Design (CSE299) · Spring 2020",
    summary:
      "A low-cost assistive system for elderly and disabled users who cannot move or speak. Gestures captured by a " +
      "Pi-camera are detected with OpenCV, and a companion Android app places an emergency call when a gesture is " +
      "recognized. The work was later published at ICCIT 2025.",
    highlights: [
      "Gesture detection with OpenCV on a Raspberry Pi and Pi-camera",
      "Android app triggers emergency calls from detected gestures",
      "Firebase backend connecting the device and the app",
      "Published at ICCIT 2025",
    ],
    why:
      "People who cannot move or speak still need a way to call for help, and the existing options were " +
      "too expensive. I wanted to see how far a cheap camera and OpenCV could go.",
    spotlight: [
      "Reliable gesture detection with a cheap Pi-camera under changing indoor lighting.",
      "Keeping it low-cost meant no depth sensors, so everything ran on OpenCV with a hand-built dataset.",
    ],
    lessons: [
      "Building and cleaning a custom dataset matters more than model choice.",
      "The work later became an ICCIT 2025 paper, my first first-author publication.",
    ],
    tech: ["Python", "OpenCV", "Raspberry Pi", "Firebase", "Android"],
    status: "completed",
    links: [{ label: "paper (doi pending)", url: "#" }],
    keyPhrases: [
      "low-cost assistive system",
      "OpenCV",
      "emergency call",
      "gesture detection",
      "ICCIT 2025",
    ],
  },
  shouhardo: {
    id: "shouhardo",
    title: "Shouhardo: Hospital Accessibility Platform",
    meta: "Directed Research (CSE498R) · Fall 2021",
    summary:
      "An HCI study and platform built during COVID-19. We interviewed 32 participants and found recurring problems: " +
      "unclear hospital information, inflated medicine prices, and difficulty finding the right doctor. We then built " +
      "a multilingual web platform with guidance, service details, and doctor availability.",
    highlights: [
      "Qualitative study with 32 participants during COVID-19",
      "Found unclear hospital information, inflated prices, and trouble finding doctors",
      "Multilingual web platform with guidance, service details, and doctor availability",
      "Published at the 6th Asian CHI Symposium 2022",
    ],
    why:
      "During COVID-19, patients in Bangladesh could not find clear hospital information, fair medicine " +
      "prices, or the right doctor. We wanted to understand the problem properly before building anything.",
    spotlight: [
      "Turning 32 qualitative interviews into concrete design requirements for a multilingual web platform.",
    ],
    lessons: [
      "Qualitative research methods: interviewing, coding responses, and finding themes.",
      "Designing for users with low technical literacy.",
      "The study was published at the 6th Asian CHI Symposium 2022.",
    ],
    tech: ["HTML", "CSS", "WordPress", "HCI Research"],
    status: "completed",
    links: [
      {
        label: "proceedings ↗",
        url: "https://drive.google.com/file/d/1ifFX5Vd1_dNN7jzyPAT1Wl0iYt5vI1YH/view",
      },
    ],
    keyPhrases: [
      "32 participants",
      "COVID-19",
      "hospital information",
      "multilingual web platform",
      "6th Asian CHI Symposium 2022",
    ],
  },
};

/* ------------------------------------------------------- small utilities -- */

function queryRequired<T extends Element>(selector: string): T {
  const el: Element | null = document.querySelector(selector);
  if (el === null) {
    throw new Error("Required element not found: " + selector);
  }
  return el as T;
}

function safeSessionStorageGet(key: string): string | null {
  try {
    return window.sessionStorage.getItem(key);
  } catch (error: unknown) {
    return null; // storage unavailable (e.g. some file:// contexts)
  }
}

function safeSessionStorageSet(key: string, value: string): void {
  try {
    window.sessionStorage.setItem(key, value);
  } catch (error: unknown) {
    /* storage unavailable; the no-repeat guarantee simply will not persist */
  }
}

function prefersReducedMotion(): boolean {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function el(tag: string, className: string, text: string): HTMLElement {
  const node: HTMLElement = document.createElement(tag);
  if (className !== "") {
    node.className = className;
  }
  node.textContent = text;
  return node;
}

/* Show an animated layer: remove [hidden], then add .open on the next frame. */
function showLayer(layer: HTMLElement): void {
  layer.hidden = false;
  if (prefersReducedMotion()) {
    layer.classList.add("open");
    return;
  }
  window.requestAnimationFrame(function (): void {
    window.requestAnimationFrame(function (): void {
      layer.classList.add("open");
    });
  });
}

/* Hide an animated layer: drop .open, then restore [hidden] after the fade. */
function hideLayer(layer: HTMLElement): void {
  layer.classList.remove("open");
  if (prefersReducedMotion()) {
    layer.hidden = true;
    return;
  }
  window.setTimeout(function (): void {
    if (!layer.classList.contains("open")) {
      layer.hidden = true;
    }
  }, ANIMATION_MS);
}

/* ----------------------------------------- 0. dynamic highlight palette --
   Every full page load rolls one of the HIGHLIGHT_PALETTES at random,
   re-rolling once if it matches the previous palette of this tab session
   (stored in sessionStorage). The chosen colors are written as inline
   custom properties on <html> before the first paint (this script runs
   synchronously at the end of <body>), so they override the stylesheet
   fallbacks. Each page is a separate HTML file, so navigating re-rolls;
   that is intentional. */

function rollPaletteIndex(): number {
  const count: number = HIGHLIGHT_PALETTES.length;
  let index: number = Math.floor(Math.random() * count);
  const lastRaw: string | null = safeSessionStorageGet(PALETTE_STORAGE_KEY);
  const last: number = lastRaw === null ? -1 : parseInt(lastRaw, 10);
  if (count > 1 && last === index) {
    /* re-roll: pick any of the other palettes deterministically from a
       fresh random offset, so an immediate repeat is impossible */
    const offset: number = 1 + Math.floor(Math.random() * (count - 1));
    index = (index + offset) % count;
  }
  safeSessionStorageSet(PALETTE_STORAGE_KEY, String(index));
  return index;
}

function applyPalette(palette: HighlightPalette): void {
  const rootStyle: CSSStyleDeclaration = document.documentElement.style;
  rootStyle.setProperty("--hl-y-light", palette.colors.colorA);
  rootStyle.setProperty("--hl-g-light", palette.colors.colorB);
  rootStyle.setProperty("--hl-p-light", palette.colors.colorC);
  rootStyle.setProperty("--hl-b-light", palette.colors.colorD);
  rootStyle.setProperty("--hl-head-light", palette.colors.headCyan);
}

function initPalette(): void {
  applyPalette(HIGHLIGHT_PALETTES[rollPaletteIndex()]);
}

/* ------------------------------------------------- 1. page transitions --
   On load the body fades/slides in (.page-in). Clicking an internal .html
   link plays a short exit fade before navigation. Returning via back/forward
   from the bfcache restores visibility instantly (pageshow.persisted). */

function currentPageFile(): string {
  const path: string = window.location.pathname;
  const file: string = path.substring(path.lastIndexOf("/") + 1);
  return file === "" ? "index.html" : file;
}

/* Returns the absolute target URL when a link click should be animated,
   or null when the browser should handle the click normally. */
function transitionTarget(anchor: HTMLAnchorElement): string | null {
  if (anchor.target === "_blank") {
    return null;
  }
  const href: string | null = anchor.getAttribute("href");
  if (href === null || href === "") {
    return null;
  }
  if (href.charAt(0) === "#") {
    return null; // in-page anchor
  }
  if (href.toLowerCase().indexOf("mailto:") === 0) {
    return null;
  }
  let url: URL;
  try {
    url = new URL(href, window.location.href);
  } catch (error: unknown) {
    return null;
  }
  // same-origin check; under file:// the host is empty on both sides
  if (url.protocol !== window.location.protocol || url.host !== window.location.host) {
    return null;
  }
  if (!url.pathname.toLowerCase().endsWith(".html")) {
    return null;
  }
  return url.href;
}

function initPageTransitions(): void {
  let exiting: boolean = false;

  // entry animation: body starts hidden in CSS, .page-in reveals it
  if (prefersReducedMotion()) {
    document.body.classList.add("page-in");
  } else {
    window.requestAnimationFrame(function (): void {
      window.requestAnimationFrame(function (): void {
        document.body.classList.add("page-in");
      });
    });
  }

  // exit animation for internal page links
  document.addEventListener("click", function (event: MouseEvent): void {
    if (event.defaultPrevented || exiting) {
      return;
    }
    if (event.button !== 0) {
      return;
    }
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
      return;
    }
    const target: EventTarget | null = event.target;
    if (!(target instanceof Element)) {
      return;
    }
    const anchor: HTMLAnchorElement | null = target.closest("a");
    if (anchor === null) {
      return;
    }
    const destination: string | null = transitionTarget(anchor);
    if (destination === null) {
      return;
    }
    event.preventDefault();
    exiting = true;
    if (prefersReducedMotion()) {
      window.location.href = destination;
      return;
    }
    document.body.classList.add("page-exit");
    window.setTimeout(function (): void {
      window.location.href = destination;
    }, EXIT_ANIMATION_MS);
  });

  // bfcache restore: the page kept its .page-exit state; reveal it instantly
  window.addEventListener("pageshow", function (event: PageTransitionEvent): void {
    if (event.persisted) {
      exiting = false;
      document.body.classList.remove("page-exit");
      document.body.classList.add("page-in");
    }
  });
}

/* --------------------------------- 2. current-page marker in the nav --
   Replaces the old scroll-spy: the nav link whose href matches the current
   filename gets the accent marker and aria-current="page". Works from
   file:// because it only compares location.pathname's filename. */

function initCurrentPageNav(): void {
  const file: string = currentPageFile();
  const links: NodeListOf<HTMLAnchorElement> = document.querySelectorAll(".nav-links a");
  links.forEach(function (link: HTMLAnchorElement): void {
    const href: string | null = link.getAttribute("href");
    if (href !== null && href === file) {
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    }
  });
}

/* ----------------------------------------------------- 3. mobile nav menu -- */

function initMobileNav(): void {
  const menuButton: HTMLButtonElement = queryRequired<HTMLButtonElement>("#menuToggle");
  const navLinks: HTMLElement = queryRequired<HTMLElement>("#navLinks");
  const nav: HTMLElement = queryRequired<HTMLElement>("nav");

  function closeMenu(): void {
    navLinks.classList.remove("open");
    menuButton.setAttribute("aria-expanded", "false");
  }

  menuButton.addEventListener("click", function (event: MouseEvent): void {
    const isOpen: boolean = navLinks.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
  });

  // close after tapping a link
  const links: NodeListOf<HTMLAnchorElement> = navLinks.querySelectorAll("a");
  links.forEach(function (link: HTMLAnchorElement): void {
    link.addEventListener("click", function (event: MouseEvent): void {
      closeMenu();
    });
  });

  // close on outside click
  document.addEventListener("click", function (event: MouseEvent): void {
    const target: EventTarget | null = event.target;
    if (target instanceof Node && !nav.contains(target)) {
      closeMenu();
    }
  });

  // close on Escape
  document.addEventListener("keydown", function (event: KeyboardEvent): void {
    if (event.key === "Escape") {
      closeMenu();
    }
  });
}

/* -------------------------------------------------- 5. reveal on scroll -- */

function initReveal(): void {
  const elements: NodeListOf<HTMLElement> = document.querySelectorAll(".reveal");

  if (prefersReducedMotion()) {
    elements.forEach(function (element: HTMLElement): void {
      element.classList.add("visible");
    });
    return;
  }

  const observer: IntersectionObserver = new IntersectionObserver(
    function (entries: IntersectionObserverEntry[]): void {
      entries.forEach(function (entry: IntersectionObserverEntry): void {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      root: REVEAL_OPTIONS.root as Element | null,
      rootMargin: REVEAL_OPTIONS.rootMargin,
      threshold: REVEAL_OPTIONS.threshold,
    }
  );

  elements.forEach(function (element: HTMLElement): void {
    observer.observe(element);
  });
}

/* -------------------- 7. project detail modal (projects + home featured) --
   The same cards, data map, and modal run on projects.html and on the
   featured-projects section of index.html. The modal artwork is a deep
   clone of the card's own art: the inline <svg class="proj-svg"> becomes
   <svg class="modal-svg playing"> so its CSS loops run while the modal is
   open (a real photo swapped in as <img class="proj-img"> is cloned into
   a plain .modal-img instead). */

function appendBulletList(container: HTMLElement, items: string[]): void {
  const list: HTMLUListElement = document.createElement("ul");
  list.className = "modal-highlights";
  items.forEach(function (item: string): void {
    const li: HTMLLIElement = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
  container.appendChild(list);
}

function buildModalContent(
  container: HTMLElement,
  detail: ProjectDetail,
  cardArt: Element | null
): void {
  container.textContent = "";

  if (cardArt instanceof SVGSVGElement) {
    /* clone the card's inline animated SVG; the .playing class lets its
       loops run while the modal is open (still paused under reduced
       motion, which forces animation: none in the stylesheet). The
       clone keeps the original role="img" + aria-label. */
    const svgClone: SVGSVGElement = cardArt.cloneNode(true) as SVGSVGElement;
    svgClone.setAttribute("class", "modal-svg playing");
    container.appendChild(svgClone);
  } else if (cardArt instanceof HTMLImageElement) {
    /* fallback: the card art was swapped for a real photo
       (<img class="proj-img">, see README section 7) */
    const image: HTMLImageElement = document.createElement("img");
    image.className = "modal-img";
    image.src = cardArt.getAttribute("src") || "";
    image.alt = cardArt.getAttribute("alt") || detail.title;
    container.appendChild(image);
  }

  const title: HTMLElement = el("h3", "modal-title", detail.title);
  title.id = "modalTitle";
  container.appendChild(title);

  container.appendChild(el("div", "modal-meta", detail.meta));
  container.appendChild(el("p", "modal-summary", detail.summary));

  container.appendChild(el("div", "modal-sub", "// highlights"));
  appendBulletList(container, detail.highlights);

  container.appendChild(el("div", "modal-sub", "// why I built it"));
  container.appendChild(el("p", "modal-why", detail.why));

  container.appendChild(el("div", "modal-sub", "// the hard part"));
  appendBulletList(container, detail.spotlight);

  container.appendChild(el("div", "modal-sub", "// what I learned"));
  appendBulletList(container, detail.lessons);

  const tags: HTMLElement = el("div", "modal-tags", "");
  detail.tech.forEach(function (name: string): void {
    tags.appendChild(el("span", "tag", name));
  });
  container.appendChild(tags);

  const status: HTMLElement = el("div", "modal-status", "");
  const statusLabel: HTMLElement = el("b", "", "status:");
  status.appendChild(statusLabel);
  status.appendChild(document.createTextNode(" " + detail.status));
  container.appendChild(status);

  if (detail.links.length > 0) {
    const linksRow: HTMLElement = el("div", "modal-links", "");
    detail.links.forEach(function (link: ProjectLink): void {
      const anchor: HTMLAnchorElement = document.createElement("a");
      anchor.href = link.url;
      anchor.textContent = link.label;
      markExternalLink(anchor);
      linksRow.appendChild(anchor);
    });
    container.appendChild(linksRow);
  }

  /* wrap the first occurrence of each key phrase in a .modal-hl span
     (text-node surgery only; the copy never goes through innerHTML) */
  wrapKeyPhrases(container, detail.keyPhrases);
}

/* Wraps the FIRST case-sensitive occurrence of phrase inside root in a
   <span class="modal-hl VARIANT">, by splitting the text node that contains
   it. The variant class (modal-hl-a/b/c) picks the marker color. Does
   nothing when the phrase is empty or absent from root. */
function wrapFirstOccurrence(root: HTMLElement, phrase: string, variantClass: string): void {
  if (phrase === "") {
    return;
  }
  const walker: TreeWalker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let current: Node | null = walker.nextNode();
  while (current !== null) {
    const text: string = current.nodeValue === null ? "" : current.nodeValue;
    const at: number = text.indexOf(phrase);
    if (at !== -1) {
      const textNode: Text = current as Text;
      /* split into [before][phrase][rest], then swap the phrase node for a span */
      const mid: Text = textNode.splitText(at);
      mid.splitText(phrase.length);
      const parent: Node | null = mid.parentNode;
      if (parent !== null) {
        const span: HTMLElement = document.createElement("span");
        span.className = "modal-hl " + variantClass;
        span.appendChild(document.createTextNode(mid.nodeValue === null ? "" : mid.nodeValue));
        parent.replaceChild(span, mid);
      }
      return;
    }
    current = walker.nextNode();
  }
}

/* modal key-phrase color variants: cycle the palette's three content colors
   so successive phrases inside one modal get different colors */
const MODAL_HL_VARIANTS: string[] = ["modal-hl-a", "modal-hl-b", "modal-hl-c"];

/* Walks the freshly built modal sections (summary, why, and the three
   bullet lists) and wraps the first occurrence of each key phrase per
   element; phrases missing from an element are simply skipped. Each phrase
   keeps one variant color wherever it appears, and the variant cycles per
   phrase so neighboring phrases differ. */
function wrapKeyPhrases(container: HTMLElement, phrases: string[]): void {
  if (phrases.length === 0) {
    return;
  }
  const targets: HTMLElement[] = Array.from(
    container.querySelectorAll<HTMLElement>(".modal-summary, .modal-why, .modal-highlights li")
  );
  targets.forEach(function (target: HTMLElement): void {
    phrases.forEach(function (phrase: string, index: number): void {
      wrapFirstOccurrence(target, phrase, MODAL_HL_VARIANTS[index % MODAL_HL_VARIANTS.length]);
    });
  });
}

function initProjectModal(): void {
  const backdropEl: HTMLElement | null = document.querySelector<HTMLElement>("#projectModalBackdrop");
  const contentEl: HTMLElement | null = document.querySelector<HTMLElement>("#modalContent");
  const closeBtn: HTMLButtonElement | null = document.querySelector<HTMLButtonElement>("#modalClose");
  if (backdropEl === null || contentEl === null || closeBtn === null) {
    return; // not on this page
  }
  const backdrop: HTMLElement = backdropEl;
  const content: HTMLElement = contentEl;
  const closeButton: HTMLButtonElement = closeBtn;
  const cards: NodeListOf<HTMLElement> = document.querySelectorAll(".proj-card[data-project]");

  let originCard: HTMLElement | null = null;
  let isOpen: boolean = false;

  function openModal(card: HTMLElement): void {
    const key: string | null = card.getAttribute("data-project");
    if (key === null) {
      return;
    }
    const detail: ProjectDetail | undefined = PROJECT_DETAILS[key];
    if (detail === undefined) {
      return;
    }

    const cardArt: Element | null = card.querySelector(".proj-svg, .proj-img");
    buildModalContent(content, detail, cardArt);

    originCard = card;
    isOpen = true;
    showLayer(backdrop);
    document.body.style.overflow = "hidden";
    closeButton.focus();
    /* sweep in the cyan sub-heads/status label and the wrapped key phrases
       right after the modal appears, staggered in DOM order; the content is
       rebuilt from scratch on every open, so closing and reopening replays
       the sweeps. Reduced motion applies the full highlight instantly. */
    const subHeads: HTMLElement[] = Array.from(
      content.querySelectorAll<HTMLElement>(".modal-sub, .modal-status b")
    );
    const spans: HTMLElement[] = Array.from(content.querySelectorAll<HTMLElement>(".modal-hl"));
    const turnOn = function (): void {
      let stagger: number = 0;
      subHeads.forEach(function (sub: HTMLElement): void {
        sub.style.transitionDelay = String(stagger * MODAL_SWEEP_STAGGER_MS) + "ms";
        sub.classList.add("modal-sweep-on");
        stagger += 1;
      });
      spans.forEach(function (span: HTMLElement): void {
        span.style.transitionDelay = String(stagger * MODAL_SWEEP_STAGGER_MS) + "ms";
        span.classList.add("modal-hl-on");
        stagger += 1;
      });
    };
    if (prefersReducedMotion()) {
      turnOn();
    } else {
      window.requestAnimationFrame(turnOn);
    }
  }

  function closeModal(): void {
    if (!isOpen) {
      return;
    }
    isOpen = false;
    hideLayer(backdrop);
    document.body.style.overflow = "";
    if (originCard !== null) {
      originCard.focus();
      originCard = null;
    }
  }

  cards.forEach(function (card: HTMLElement): void {
    card.addEventListener("click", function (event: MouseEvent): void {
      openModal(card);
    });
    card.addEventListener("keydown", function (event: KeyboardEvent): void {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openModal(card);
      }
    });
  });

  closeButton.addEventListener("click", function (event: MouseEvent): void {
    closeModal();
  });

  // backdrop click: only when the click lands outside the panel
  backdrop.addEventListener("click", function (event: MouseEvent): void {
    if (event.target === backdrop) {
      closeModal();
    }
  });

  document.addEventListener("keydown", function (event: KeyboardEvent): void {
    if (event.key === "Escape" && isOpen) {
      event.stopPropagation();
      closeModal();
    }
  });
}

/* ----------------------- 8. staggered hero entrance (index only) --
   Hero elements fade and translate in one by one (~60ms apart), playing
   together with the page-entry transition, once per load. The elements are
   hidden only by the .hero-stagger class added here (before the first paint),
   so nothing flashes on other pages and reduced motion shows everything. */

function initHeroIntro(): void {
  const hero: HTMLElement | null = document.querySelector<HTMLElement>(".hero");
  if (hero === null) {
    return; // not the home page
  }
  if (prefersReducedMotion()) {
    return;
  }
  const selectors: string[] = [".hero-cmd", "h1", ".role", ".tags", ".hero-links", ".profile-photo"];
  const items: HTMLElement[] = [];
  selectors.forEach(function (selector: string): void {
    const item: HTMLElement | null = hero.querySelector<HTMLElement>(selector);
    if (item !== null) {
      items.push(item);
    }
  });

  items.forEach(function (item: HTMLElement): void {
    item.classList.add("hero-stagger");
  });

  window.requestAnimationFrame(function (): void {
    window.requestAnimationFrame(function (): void {
      items.forEach(function (item: HTMLElement, index: number): void {
        item.style.transitionDelay = String(index * HERO_STAGGER_MS) + "ms";
        item.classList.add("hero-in");
      });
      // clean up so the delay does not affect later hover transitions
      const totalMs: number = (items.length - 1) * HERO_STAGGER_MS + 300;
      window.setTimeout(function (): void {
        items.forEach(function (item: HTMLElement): void {
          item.style.transitionDelay = "";
          item.classList.remove("hero-stagger", "hero-in");
        });
      }, totalMs);
    });
  });
}

/* ---------------- 9. keyword marker highlights (site-wide) --
   Scroll-triggered marker sweep on highlighted phrases anywhere on the
   site (about paragraphs, hero role, research interests, experience
   roles, news), marked in the HTML with a variant class (.hl-y research
   topics, .hl-g roles and affiliations, .hl-p calls to action, .hl-b the
   extra chunks of long phrases). This module adds .hl up front (so with
   JS off a <b> keeps its plain bold style) and .hl-on when the phrase
   scrolls into view; above-the-fold phrases (e.g. the hero role) are
   already intersecting, so they sweep on page entry. Once lit a phrase
   STAYS lit: the class is never removed and the phrase is unobserved.
   Phrases entering in the same frame light up in sequence, staggered by
   HIGHLIGHT_STAGGER_MS; one observer handles all variants.
   Project-card description keywords (.proj-desc) are deliberately
   excluded: they stay hover/focus-only together with the card title
   (style.css, "KEYWORD MARKER HIGHLIGHTS").
   Reduced motion: highlights appear instantly. */

function initHighlights(): void {
  const phrases: HTMLElement[] = Array.from(
    document.querySelectorAll<HTMLElement>(".hl-y, .hl-g, .hl-p, .hl-b")
  ).filter(function (phrase: HTMLElement): boolean {
    /* card description keywords sweep on card hover/focus only */
    return phrase.closest(".proj-desc") === null;
  });
  if (phrases.length === 0) {
    return; // no highlighted phrases on this page
  }

  phrases.forEach(function (phrase: HTMLElement): void {
    phrase.classList.add("hl");
  });

  if (prefersReducedMotion()) {
    phrases.forEach(function (phrase: HTMLElement): void {
      phrase.classList.add("hl-on");
    });
    return;
  }

  const observer: IntersectionObserver = new IntersectionObserver(
    function (entries: IntersectionObserverEntry[]): void {
      let stagger: number = 0;
      entries.forEach(function (entry: IntersectionObserverEntry): void {
        if (!entry.isIntersecting) {
          return;
        }
        const phrase: HTMLElement = entry.target as HTMLElement;
        phrase.style.transitionDelay = String(stagger * HIGHLIGHT_STAGGER_MS) + "ms";
        phrase.classList.add("hl-on");
        stagger += 1;
        observer.unobserve(phrase);
      });
    },
    {
      root: HIGHLIGHT_OPTIONS.root as Element | null,
      rootMargin: HIGHLIGHT_OPTIONS.rootMargin,
      threshold: HIGHLIGHT_OPTIONS.threshold,
    }
  );

  phrases.forEach(function (phrase: HTMLElement): void {
    observer.observe(phrase);
  });
}

/* ---------------------- 10. external links open in a new tab --
   Runtime safety net over the static HTML: every anchor whose href uses an
   absolute http(s) scheme gets target="_blank" + rel="noopener noreferrer".
   Internal .html navigation, same-page anchors, the skip link, and mailto
   links never match the scheme selector and stay same-tab. Modal project
   links are rendered after this pass, so buildModalContent routes each of
   them through markExternalLink itself. */

function markExternalLink(anchor: HTMLAnchorElement): void {
  const href: string | null = anchor.getAttribute("href");
  if (href === null) {
    return;
  }
  const scheme: string = href.toLowerCase();
  if (scheme.indexOf("https://") === 0 || scheme.indexOf("http://") === 0) {
    anchor.target = "_blank";
    anchor.rel = "noopener noreferrer";
  }
}

function initExternalLinks(): void {
  const anchors: NodeListOf<HTMLAnchorElement> = document.querySelectorAll(
    'a[href^="http://"], a[href^="https://"]'
  );
  anchors.forEach(function (anchor: HTMLAnchorElement): void {
    markExternalLink(anchor);
  });
}

/* -------------------- 11. page-heading highlight sweep --
   The word part of every .sec-head (wrapped in .sec-word) gets a marker
   sweep in the rolled palette's cyan heading color. The first heading plays
   right after the entry transition begins (a short delay: it is above the
   fold); the rest are observed and sweep in once, staggered, as they enter
   the viewport. This runs the same way on every page. On a bfcache restore
   the classes are still applied from the original load and this init does
   not rerun, so the sweeps never replay.
   Reduced motion: the highlight is applied instantly. */

const HEADING_OBSERVE_OPTIONS: ObserverConfig = {
  root: null,
  rootMargin: "0px 0px -10% 0px",
  threshold: 0.4,
};

function initHeadingSweep(): void {
  const words: HTMLElement[] = Array.from(
    document.querySelectorAll<HTMLElement>(".sec-head .sec-word")
  );
  if (words.length === 0) {
    return;
  }
  /* every page sweeps every .sec-word: the first on entry, the rest via a
     one-shot IntersectionObserver */
  const targets: HTMLElement[] = words;

  if (prefersReducedMotion()) {
    targets.forEach(function (word: HTMLElement): void {
      word.classList.add("sec-word-on");
    });
    return;
  }

  window.setTimeout(function (): void {
    targets[0].classList.add("sec-word-on");
  }, HEADING_SWEEP_DELAY_MS);

  if (targets.length > 1) {
    const observer: IntersectionObserver = new IntersectionObserver(
      function (entries: IntersectionObserverEntry[]): void {
        let stagger: number = 0;
        entries.forEach(function (entry: IntersectionObserverEntry): void {
          if (entry.isIntersecting) {
            const word: HTMLElement = entry.target as HTMLElement;
            word.style.transitionDelay = String(stagger * HIGHLIGHT_STAGGER_MS) + "ms";
            word.classList.add("sec-word-on");
            stagger += 1;
            observer.unobserve(word);
          }
        });
      },
      {
        root: HEADING_OBSERVE_OPTIONS.root as Element | null,
        rootMargin: HEADING_OBSERVE_OPTIONS.rootMargin,
        threshold: HEADING_OBSERVE_OPTIONS.threshold,
      }
    );
    targets.forEach(function (word: HTMLElement, index: number): void {
      if (index > 0) {
        observer.observe(word);
      }
    });
  }
}

/* ------------------------------------------------------ 12. footer year -- */

function initFooterYear(): void {
  const yearSpan: HTMLElement = queryRequired<HTMLElement>("#year");
  const now: Date = new Date();
  yearSpan.textContent = String(now.getFullYear());
}

/* ------------------------------------------------------------------- init -- */

/* Run before the first paint (this script sits at the end of <body>): roll
   and apply the highlight palette, and start the page-entry transition. */
initPalette();
initPageTransitions();

function init(): void {
  initMobileNav();
  initCurrentPageNav();
  initReveal();
  initProjectModal();
  initHeroIntro();
  initHighlights();
  initExternalLinks();
  initHeadingSweep();
  initFooterYear();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", function (event: Event): void {
    init();
  });
} else {
  init();
}
