import subprocess, time
from playwright.sync_api import sync_playwright
server = subprocess.Popen(["python3","-m","http.server","8615","--bind","127.0.0.1"], cwd="/mnt/agents/output/app", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
with sync_playwright() as pw:
    b = pw.chromium.launch()
    pg = b.new_page(viewport={"width":1280,"height":800})
    pg.goto("http://127.0.0.1:8615/index.html")
    pg.add_style_tag(content="html { scroll-behavior: auto !important; }")
    pg.wait_for_timeout(1600)
    for i in range(6):
        info = pg.evaluate("""() => {
          const ps = document.querySelectorAll('#about p');
          const r = ps[1].getBoundingClientRect();
          const before = window.scrollY;
          window.scrollTo(0, window.scrollY + r.top - 758);
          return {top: r.top, before: before, after: window.scrollY, n: ps.length};
        }""")
        print(i, info)
        pg.wait_for_timeout(400)
        print("   later scrollY:", pg.evaluate("() => window.scrollY"))
    b.close()
server.terminate()
