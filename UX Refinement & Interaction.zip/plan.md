# Plan — Portfolio Refinement (Round 4): Apply "Building an Effective Dev Portfolio" guidance

Reference: /mnt/agents/temp/building-an-effective-dev-portfolio.md (Joshua Comeau). Site: /mnt/agents/output/app/ (v3 multi-page).

## Advice selected (judgment call, fits academic robotics context + user's minimal style)
1. **Home must-haves**: home currently lacks projects + contact. Add `featured projects` (2 current projects, reuse card+modal, link to projects.html) and a `get in touch` strip (email/links + contact.html link).
2. **Tour-guide project details**: extend modal data model with `why` (purpose/goal), `spotlight` (hardest technical part + how solved), `lessons` (what was learned). Render as skimmable `//` subsections. Honest content derived from CV/old site.
3. **Personal, memorable About**: add short authentic personal paragraph (football, coin collecting, butterfly-effect fascination from his own old site) + implicit humility/mentorship tone. No bravado anywhere.
4. **Sprinkles**: subtle staggered hero entrance animation on home (reduced-motion safe).
5. **Accessibility**: add skip-to-content link on all pages (rest already strong).
6. **README**: custom-domain tip + how to edit project narratives.

## Explicitly NOT applied (with reasons)
- Developer blog (book says keep separate), skill bars/charts (book forbids), testimonials, contact form backend (static host; mailto is book-sanctioned), >5 projects.

## Stage R2 — Build (coder subagent, foreground)
Edit in place; extend ProjectDetail interface; recompile tsc strict; verify.

## Stage R3 — Verify & deliver (orchestrator)
grep dashes=0, screenshots (home, modal with new sections), zip, build_version.

## Round 9 (current): simplify interactions, remove dark mode
User request:
1. Card hover highlights ONLY the project title (no persistent highlight while modal open).
2. Card click opens modal where important words in the description and other sections get the marker highlight.
3. Remove the neon glow effect entirely.
4. Remove night/dark mode entirely (toggle, dark tokens, dark palette variants, glow tokens).

Stage A - Implementation (coder subagent):
- Strip theme system from all 6 HTML pages + main.ts + style.css; light-only.
- Simplify palette system to light colors only; remove darkGlow and all glow/box-shadow halo rules.
- Remove .card-open persistence; modal open lets title sweep back out.
- Add ProjectDetail.keyPhrases + modal text-node wrapping -> .modal-hl spans swept on open.
- README update; tsc 5.9.3 strict recompile; commit immediately after verification.
Stage B - Orchestrator verification: greps (no dark/theme/glow/neon remnants), node --check, screenshots.
Stage C - Rebuild zip + website_version_manager build_version + final response.

## Round 9 — cyan heading system, selective keyword highlights, static profile, light-only
Current tree is partially migrated (dark mode + neon glow already removed, modal keyPhrases infra exists but .modal-hl CSS missing).
Stage 1 (coder subagent):
 1. Cyan highlighter for ALL major headings site-wide: palette headTint -> cyan shades (vary per palette), CSS fallback cyan, experience "education" gets .sec-word, initHeadingSweep animates every sec-word on every page.
 2. Card titles: wrap ENTIRE title in .card-hl (7 cards), color = cyan (--hl-head), hover/focus sweep only.
 3. Modal: .modal-sub + "status:" label sweep cyan on open; add missing .modal-hl CSS (varied palette colors cycling per phrase).
 4. Selective keyword highlights: remove institution highlights (NSU, NIRO Lab, NSU Ignite); add "Research Assistant", "autonomous robots", "segmentation-based vision" in About; hero role keyword; research interest lead terms; xp-role titles; one key phrase per projects-page card desc; news BEAR phrase. Generalize .hl CSS site-wide + shared scroll observer.
 5. Profile photo: fully static (remove button/overlay/JS/zoom CSS), enlarge 148->176 (mobile 112->128).
 6. .hero-cmd 13.5->15px; small label bumps per judgment.
 7. Palette interface rename/comments, README update, conservative polish pass.
Constraints: no frameworks, zero em/en dashes, tsc 5.9 strict recompile, reduced-motion instant, file:// safe, git init+commit (tree resets), headless verification + shots10/.
Stage 2 (orchestrator): verify, zip rebuild, website_version_manager build_version, deliver.

## Round 10 — multi-color chunked highlights, timeline layout, black headings, pub order, nav sizes
Stage 1 (coder): 
 1. Split About's long hl-y phrase into 4 meaningful chunks with varied palette colors (add 4th content color per palette if needed); chunk the long CTA phrase too.
 2. Featured Projects (homepage): remove hl spans from card descriptions; title-only highlight on hover; modal keeps highlighted content on click.
 3. Experience timeline: content moves to LEFT of the vertical line (line/dot on right of entry block), responsive.
 4. .sec-head color var(--accent) -> var(--ink) (black headings, cyan sweep stays).
 5. Publications: reorder descending by year (2025, 2022, 2020, 2020), renumber.
 6. .nav-name 14->15.5px; .nav-links 13.5->14.5px.
Constraints: same as round 9 (commit safety, tsc 5.9 strict, no em/en dashes, reduced-motion, headless verify + shots11/).
Stage 2: verify, zip, build_version, deliver.

## Round 11 — timeline dates left of line, slower sweeps, README rewrite
Stage 1 (coder):
 1. Experience timeline: line/dot back to LEFT; date moves to a left column (left of the line), details right of line; responsive stacking on mobile.
 2. Slow highlight sweeps ~1.4x (.hl .55->.8s, .sec-word .6->.85s, .card-hl/.modal-hl .45->.7s).
 3. README.md full rewrite: step-by-step guide for updating personal info (text, news, projects + ProjectDetail + keyPhrases, experience entries, publications, images, palettes, links, deployment).
Stage 2: verify, zip, build_version, deliver.

## Round 12 — interaction-only highlights + animated SVG placeholders
Stage 1 (coder):
 1. Keyword highlights (.hl) become interaction-triggered (CSS :hover/:focus-within on containing block), remove initHighlights scroll JS; projects-page card desc keywords highlight on card hover only. Heading sweeps stay (page navigation = the interaction).
 2. Replace static <img> card art with inline animated SVG placeholders (paused by default; play on card hover/focus and inside open modal; SMIL-free, CSS keyframes; reduced-motion = never play; keep [ replace: x.jpg ] labels). Modal clones card SVG.
 3. README updates (highlight triggers, inline SVG replacement guide).
Stage 2: verify (nothing highlighted/animated at rest; hover activates; modal activates), zip, build_version, deliver.

## Round 13 — restore scroll-triggered keyword highlights (undo round-12 hover triggers)
Stage 1 (coder): restore initHighlights IntersectionObserver (one-shot, stays highlighted) for all .hl EXCEPT projects-page card description keywords (those stay hover-only with the card). Remove hover/focus keyword triggers for about/hero/news/research/experience. Keep: card hovers (title + desc + SVG art), modal highlights, heading sweeps. Reference git commit e867eb2 for the removed mechanism. README update.
Stage 2: verify, zip, build_version, deliver.
