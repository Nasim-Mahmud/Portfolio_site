import subprocess, time
from playwright.sync_api import sync_playwright
server = subprocess.Popen(["python3","-m","http.server","8615","--bind","127.0.0.1"], cwd="/mnt/agents/output/app", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1)
with sync_playwright() as pw:
    b = pw.chromium.launch()
    pg = b.new_page(viewport={"width":1280,"height":800})
    pg.goto("http://127.0.0.1:8615/index.html")
    pg.add_style_tag(content="html { scroll-behavior: auto !important; }")
    pg.wait_for_timeout(1600)
    # place the 2nd About paragraph's first keyword at y=752: inside the
    # bottom 8% band, so it stays unlit but visible
    for _ in range(8):
        done = pg.evaluate("""() => {
          const ps = document.querySelectorAll('#about p');
          const kw = ps[1].querySelector('.hl-y, .hl-g, .hl-p, .hl-b');
          const r = kw.getBoundingClientRect();
          if (Math.abs(r.top - 752) < 4) return true;
          window.scrollTo(0, window.scrollY + r.top - 752);
          return false;
        }""")
        pg.wait_for_timeout(300)
        if done: break
    pg.wait_for_timeout(600)
    st = pg.evaluate("""() => Array.from(document.querySelectorAll('#about .hl-y, #about .hl-g, #about .hl-p, #about .hl-b')).map(e=>({t:e.textContent.slice(0,20), on:e.classList.contains('hl-on'), bg:getComputedStyle(e).backgroundSize, top:Math.round(e.getBoundingClientRect().top)}))""")
    print(st)
    pg.screenshot(path="/mnt/agents/output/shots14/index-about-rest.png")
    b.close()
server.terminate()
