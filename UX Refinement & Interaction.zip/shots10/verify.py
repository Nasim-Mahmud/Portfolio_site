import re, threading, http.server, socketserver, functools, sys
from playwright.sync_api import sync_playwright

APP = "/mnt/agents/output/app"
SHOTS = "/mnt/agents/output/shots10"
PORT = 8613

Handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=APP)
socketserver.TCPServer.allow_reuse_address = True
srv = socketserver.TCPServer(("127.0.0.1", PORT), Handler)
threading.Thread(target=srv.serve_forever, daemon=True).start()

BASE = f"http://127.0.0.1:{PORT}"
PAGES = ["index.html", "research.html", "experience.html", "projects.html", "publications.html", "contact.html"]

def hue_of(bg):
    m = re.search(r"rgba?\((\d+),\s*(\d+),\s*(\d+)", bg or "")
    if not m:
        return None
    r, g, b = [int(x)/255 for x in m.groups()]
    mx, mn = max(r, g, b), min(r, g, b)
    if mx == mn:
        return 0
    d = mx - mn
    if mx == r:
        h = 60 * (((g - b) / d) % 6)
    elif mx == g:
        h = 60 * ((b - r) / d + 2)
    else:
        h = 60 * ((r - g) / d + 4)
    return h

results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS" if ok else "FAIL"), name, "-", detail)

def scroll_through(page):
    page.evaluate("""async () => {
        const h = document.body.scrollHeight;
        for (let y = 0; y <= h; y += 300) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 90)); }
        window.scrollTo(0, 0);
        await new Promise(r => setTimeout(r, 300));
    }""")

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox"])
    ctx = browser.new_context(viewport={"width": 1280, "height": 800})
    page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))

    # ---------- (a) every page: all sec-words swept, cyan hue ----------
    for pg in PAGES:
        page.goto(f"{BASE}/{pg}")
        page.wait_for_timeout(600)
        scroll_through(page)
        words = page.eval_on_selector_all(
            ".sec-word",
            "els => els.map(e => ({on: e.classList.contains('sec-word-on'), bg: getComputedStyle(e).backgroundImage}))")
        all_on = all(w["on"] for w in words) and len(words) > 0
        hues = [hue_of(w["bg"]) for w in words]
        cyan = all(h is not None and 180 <= h <= 200 for h in hues)
        check(f"a. {pg} sec-words all .sec-word-on", all_on, f"{len(words)} words")
        check(f"a. {pg} heading highlight cyan hue 180-200", cyan, f"hues={hues}")

    # ---------- (e) palette roll differs across reloads ----------
    page.goto(f"{BASE}/index.html")
    page.wait_for_timeout(400)
    first = page.evaluate("document.documentElement.style.getPropertyValue('--hl-y-light')")
    page.reload()
    page.wait_for_timeout(400)
    second = page.evaluate("document.documentElement.style.getPropertyValue('--hl-y-light')")
    check("e. two reloads roll different palettes", first != second, f"{first!r} vs {second!r}")

    # ---------- (d) static photo / no theme machinery ----------
    page.goto(f"{BASE}/index.html")
    page.wait_for_timeout(500)
    photo_tag = page.evaluate("document.querySelector('.profile-photo')?.tagName")
    check("d. profile photo is a div", photo_tag == "DIV", photo_tag)
    junk = page.evaluate("""() => ({
        theme: !!document.querySelector('[data-theme], #themeToggle, .theme-toggle'),
        overlay: !!document.querySelector('.overlay, #photoOverlay'),
        photoBtn: !!document.querySelector('button.profile-photo')
    })""")
    check("d. no data-theme/toggle/overlay/photo-button", not any(junk.values()), str(junk))

    # ---------- (b) card hover sweep: index ----------
    for pg in ["index.html", "projects.html"]:
        page.goto(f"{BASE}/{pg}")
        page.wait_for_timeout(700)
        cards = page.query_selector_all(".proj-card")
        ok_all, details = True, []
        for i, card in enumerate(cards):
            card.scroll_into_view_if_needed()
            page.wait_for_timeout(150)
            card.hover()
            page.wait_for_timeout(700)
            sizes = page.eval_on_selector_all(
                ".proj-card .card-hl", "els => els.map(e => getComputedStyle(e).backgroundSize)")
            hovered = page.evaluate("document.querySelectorAll('.proj-card')[%i].matches(':hover')" % i)
            this = sizes[i]
            good = hovered and this.startswith("100%")
            ok_all = ok_all and good
            details.append(f"card{i}={'100%' if good else this}")
            # pointer leave reverts
            page.mouse.move(5, 5)
            page.wait_for_timeout(600)
            after = page.eval_on_selector_all(
                ".proj-card .card-hl", "els => els.map(e => getComputedStyle(e).backgroundSize)")[i]
            ok_all = ok_all and after.startswith("0%")
        check(f"b. {pg} every card title sweeps 100% on hover, reverts on leave", ok_all, ", ".join(details))

    # ---------- (c) modal sweeps ----------
    page.goto(f"{BASE}/projects.html")
    page.wait_for_timeout(700)
    page.click(".proj-card[data-project='niro-bot']")
    page.wait_for_timeout(2600)
    subs = page.eval_on_selector_all(
        ".modal-sub, .modal-status b",
        "els => els.map(e => ({on: e.classList.contains('modal-sweep-on'), bg: getComputedStyle(e).backgroundImage, size: getComputedStyle(e).backgroundSize}))")
    subs_on = all(s["on"] and s["size"].startswith("100%") for s in subs) and len(subs) == 5
    subs_cyan = all((180 <= (hue_of(s["bg"]) or 0) <= 200) for s in subs)
    check("c. modal sub-heads + status swept cyan (5 elements)", subs_on and subs_cyan,
          f"hues={[hue_of(s['bg']) for s in subs]}")
    spans = page.eval_on_selector_all(
        ".modal-hl",
        "els => els.map(e => ({cls: e.className, on: e.classList.contains('modal-hl-on'), bg: getComputedStyle(e).backgroundImage}))")
    variants = set(re.search(r"modal-hl-[abc]", s["cls"]).group(0) for s in spans)
    hues = set(round(hue_of(s["bg"]) or -1) for s in spans)
    spans_on = all(s["on"] for s in spans) and len(spans) >= 3
    noncyan = all(not (180 <= h <= 200) for h in hues)
    check("c. modal key phrases swept, >=2 distinct non-cyan colors",
          spans_on and len(variants) >= 2 and noncyan, f"variants={sorted(variants)} hues={sorted(hues)} n={len(spans)}")
    page.screenshot(path=f"{SHOTS}/06-modal-open.png")

    # close and reopen replays
    page.click("#modalClose")
    page.wait_for_timeout(500)
    page.click(".proj-card[data-project='project-hex']")
    page.wait_for_timeout(2600)
    spans2 = page.eval_on_selector_all(
        ".modal-hl", "els => els.map(e => e.classList.contains('modal-hl-on'))")
    subs2 = page.eval_on_selector_all(
        ".modal-sub", "els => els.map(e => e.classList.contains('modal-sweep-on'))")
    check("c. close + reopen replays sweeps", len(spans2) > 0 and all(spans2) and all(subs2),
          f"spans={len(spans2)} subs={len(subs2)}")
    page.keyboard.press("Escape")
    page.wait_for_timeout(400)

    # ---------- screenshots ----------
    page.goto(f"{BASE}/index.html")
    page.wait_for_timeout(900)
    page.screenshot(path=f"{SHOTS}/01-home-hero.png")
    page.evaluate("document.querySelector('#about').scrollIntoView()")
    page.wait_for_timeout(1200)
    page.screenshot(path=f"{SHOTS}/02-home-about-keywords.png")
    el = page.query_selector("#about")
    el.screenshot(path=f"{SHOTS}/03-about-closeup.png")

    page.goto(f"{BASE}/experience.html")
    page.wait_for_timeout(700)
    page.screenshot(path=f"{SHOTS}/04-experience-heading.png")
    page.evaluate("document.querySelector('#education').scrollIntoView()")
    page.wait_for_timeout(1000)
    page.screenshot(path=f"{SHOTS}/05-experience-education-heading.png")

    page.goto(f"{BASE}/projects.html")
    page.wait_for_timeout(800)
    card = page.query_selector(".proj-card[data-project='aoaver']")
    card.hover()
    page.wait_for_timeout(700)
    page.screenshot(path=f"{SHOTS}/07-projects-hover.png", full_page=True)

    page.goto(f"{BASE}/research.html")
    page.wait_for_timeout(1300)
    page.screenshot(path=f"{SHOTS}/08-research.png")

    # ---------- file:// smoke test ----------
    page.goto(f"file://{APP}/index.html")
    page.wait_for_timeout(900)
    scroll_through(page)
    fw = page.eval_on_selector_all(
        ".sec-word", "els => els.map(e => e.classList.contains('sec-word-on'))")
    fhl = page.eval_on_selector_all(
        "#about .hl", "els => els.map(e => e.classList.contains('hl-on'))")
    check("file:// index: sec-words + about highlights sweep", all(fw) and all(fhl) and len(fhl) >= 5,
          f"words={len(fw)} about-hl={len(fhl)}")
    page.goto(f"file://{APP}/projects.html")
    page.wait_for_timeout(700)
    page.click(".proj-card[data-project='gesture']")
    page.wait_for_timeout(1400)
    fm = page.eval_on_selector_all(".modal-hl", "els => els.length")
    fms = page.eval_on_selector_all(".modal-sweep-on", "els => els.length")
    check("file:// modal opens with sweeps", fm >= 4 and fms == 5, f"phrases={fm} subs={fms}")
    page.screenshot(path=f"{SHOTS}/09-file-modal.png")

    check("no page JS errors anywhere", len(errors) == 0, "; ".join(errors[:3]))
    browser.close()

srv.shutdown()
fails = [r for r in results if not r[1]]
print("\n==== %d checks, %d failed ====" % (len(results), len(fails)))
sys.exit(1 if fails else 0)
