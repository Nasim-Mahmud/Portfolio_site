import json, sys
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8123"
OUT = "/mnt/agents/output/shots12"
results = {}

with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome", args=["--no-sandbox"])

    # ---------- A. experience.html desktop geometry (1280px) ----------
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pg.goto(f"{BASE}/experience.html")
    pg.wait_for_timeout(900)
    geo = pg.evaluate("""
      () => {
        const items = [...document.querySelectorAll('.xp-item')];
        const out = [];
        for (const it of items) {
          const when = it.querySelector('.xp-when').getBoundingClientRect();
          const body = it.querySelector('.xp-body').getBoundingClientRect();
          // line: ::before, dot: ::after -> measure via a probe element
          const probe = document.createElement('div');
          it.appendChild(probe);
          const cs = getComputedStyle(it, '::before');
          const csA = getComputedStyle(it, '::after');
          // reconstruct positions from CSS: use the pseudo offsets
          const itR = it.getBoundingClientRect();
          const lineLeft = itR.left + parseFloat(cs.left);
          const lineW = parseFloat(cs.width);
          const lineTop = itR.top + parseFloat(cs.top);
          const dotLeft = itR.left + parseFloat(csA.left);
          const dotW = parseFloat(csA.width);
          it.removeChild(probe);
          out.push({
            whenRight: when.right, bodyLeft: body.left,
            lineX: lineLeft, lineCenter: lineLeft + lineW / 2,
            dotCenter: dotLeft + dotW / 2, lineTop,
            dispBefore: cs.display, dispAfter: csA.display,
            itLeft: itR.left, itRight: itR.right
          });
        }
        const doc = document.documentElement;
        return { items: out, scrollW: doc.scrollWidth, clientW: doc.clientWidth };
      }
    """)
    results["desktop_geo"] = geo
    ok = True
    for i, it in enumerate(geo["items"]):
        cond = it["whenRight"] <= it["lineX"] and it["lineX"] < it["bodyLeft"] and abs(it["lineCenter"] - it["dotCenter"]) < 1.5
        print(f"item{i}: whenRight={it['whenRight']:.1f} lineX={it['lineX']:.1f} bodyLeft={it['bodyLeft']:.1f} lineCenter={it['lineCenter']:.1f} dotCenter={it['dotCenter']:.1f} -> {'OK' if cond else 'FAIL'}")
        ok = ok and cond
    # line continuity: line of item i should reach bottom of item i (top of next dot)
    lines = [it for it in geo["items"] if it["dispBefore"] != "none"]
    print("visible line segments:", len(lines), "of", len(geo["items"]), "(last should be hidden)")
    results["desktop_ok"] = ok and len(lines) == len(geo["items"]) - 1
    pg.screenshot(path=f"{OUT}/experience-desktop.png", full_page=True)
    pg.close()

    # ---------- A2. experience.html mobile (375px) ----------
    pg = b.new_page(viewport={"width": 375, "height": 800})
    pg.goto(f"{BASE}/experience.html")
    pg.wait_for_timeout(900)
    mob = pg.evaluate("""
      () => {
        const doc = document.documentElement;
        const it = document.querySelector('.xp-item');
        const when = it.querySelector('.xp-when').getBoundingClientRect();
        const body = it.querySelector('.xp-body').getBoundingClientRect();
        const csA = getComputedStyle(it, '::after');
        const itR = it.getBoundingClientRect();
        let maxRight = 0;
        document.querySelectorAll('#experience *').forEach(el => {
          const r = el.getBoundingClientRect();
          if (r.right > maxRight) maxRight = r.right;
        });
        return {
          scrollW: doc.scrollWidth, innerW: window.innerWidth,
          whenTop: when.top, bodyTop: body.top,
          dotLeft: itR.left + parseFloat(csA.left),
          maxRight
        };
      }
    """)
    mob["no_overflow"] = mob["scrollW"] <= mob["innerW"] + 1
    mob["date_above"] = mob["whenTop"] < mob["bodyTop"]
    print("mobile:", json.dumps(mob))
    results["mobile"] = mob
    pg.screenshot(path=f"{OUT}/experience-mobile.png", full_page=True)
    pg.close()

    # ---------- B. transition durations ----------
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pg.goto(f"{BASE}/index.html")
    pg.wait_for_timeout(300)
    durs = pg.evaluate("""
      () => {
        const grab = (sel, pseudo) => {
          const el = document.querySelector(sel);
          if (!el) return null;
          const cs = pseudo ? getComputedStyle(el, pseudo) : getComputedStyle(el);
          return cs.transitionDuration;
        };
        // build probe elements for classes not present on this page
        const probe = (cls) => {
          const s = document.createElement('span');
          s.className = cls;
          document.body.appendChild(s);
          const d = getComputedStyle(s).transitionDuration;
          s.remove();
          return d;
        };
        return {
          hl: probe('hl hl-y'),
          secWord: (() => { const el = document.querySelector('.sec-word'); return getComputedStyle(el).transitionDuration; })(),
          cardHl: (() => { const el = document.querySelector('.card-hl'); return getComputedStyle(el).transitionDuration; })(),
          modalSub: probe('modal-sub'),
          modalStatusB: (() => { const d = document.createElement('div'); d.className='modal-status'; const bb=document.createElement('b'); bb.textContent='x'; d.appendChild(bb); document.body.appendChild(d); const v=getComputedStyle(bb).transitionDuration; d.remove(); return v; })(),
          modalHl: probe('modal-hl')
        };
      }
    """)
    print("durations:", json.dumps(durs))
    results["durations"] = durs

    # sweep completes on scroll: find an .hl below fold, scroll, check hl-on
    sweep = pg.evaluate("""
      async () => {
        const els = [...document.querySelectorAll('b.hl, span.hl')];
        const below = els.find(el => el.getBoundingClientRect().top > window.innerHeight);
        if (!below) return { skipped: true };
        below.scrollIntoView({ block: 'center' });
        await new Promise(r => setTimeout(r, 1400));
        return { hasOn: below.classList.contains('hl-on'), bg: getComputedStyle(below).backgroundSize };
      }
    """)
    print("scroll sweep:", json.dumps(sweep))
    results["scroll_sweep"] = sweep
    pg.close()

    # reduced motion: durations instant
    pg = b.new_page(viewport={"width": 1280, "height": 900}, reduced_motion="reduce")
    pg.goto(f"{BASE}/index.html")
    pg.wait_for_timeout(300)
    rm = pg.evaluate("""
      () => {
        const el = document.querySelector('.sec-word');
        return getComputedStyle(el).transitionDuration;
      }
    """)
    print("reduced-motion sec-word duration:", rm)
    results["reduced_motion_secword"] = rm
    pg.close()

    # ---------- C. card hover sweep + modal + palette roll ----------
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pg.goto(f"{BASE}/projects.html")
    pg.wait_for_timeout(600)
    card = pg.locator(".proj-card").first
    card.hover()
    pg.wait_for_timeout(350)  # mid-sweep frame (0.7s transition)
    pg.screenshot(path=f"{OUT}/mid-sweep-hover.png")
    pg.wait_for_timeout(700)
    hover_bg = pg.evaluate("getComputedStyle(document.querySelector('.proj-card .card-hl')).backgroundSize")
    print("card-hl bg after hover:", hover_bg)
    results["card_hover_bg"] = hover_bg
    card.click()
    pg.wait_for_timeout(1200)
    modal = pg.evaluate("""
      () => ({
        open: document.querySelector('.modal-backdrop').classList.contains('open'),
        modalHls: document.querySelectorAll('.modal-hl.modal-hl-on').length,
        subs: document.querySelectorAll('.modal-sub.modal-sweep-on').length
      })
    """)
    print("modal:", json.dumps(modal))
    results["modal"] = modal
    pg.screenshot(path=f"{OUT}/modal-open.png")
    pg.close()

    # palette roll across reloads
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pals = []
    for i in range(3):
        pg.goto(f"{BASE}/index.html")
        pg.wait_for_timeout(250)
        v = pg.evaluate("document.documentElement.style.getPropertyValue('--hl-y-light')")
        pals.append(v)
    print("palette rolls:", pals)
    results["palettes"] = pals
    pg.close()

    # ---------- file:// smoke test ----------
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pg.goto("file:///mnt/agents/output/app/experience.html")
    pg.wait_for_timeout(700)
    fw = pg.evaluate("document.documentElement.scrollWidth")
    print("file:// experience scrollW:", fw)
    results["file_scrollW"] = fw
    pg.close()

    b.close()

print("=== SUMMARY ===")
print(json.dumps({k: v for k, v in results.items() if k != 'desktop_geo'}, indent=1)[:2000])
