import sys, time
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8137"
SHOTS = "/mnt/agents/output/shots13"

REST_JS = """() => {
  const out = {};
  const hls = Array.from(document.querySelectorAll('.hl-y,.hl-g,.hl-p,.hl-b'));
  out.hlCount = hls.length;
  out.hlVisible = hls.filter(e => !getComputedStyle(e).backgroundSize.startsWith('0%'))
    .map(e => e.textContent + '::' + getComputedStyle(e).backgroundSize);
  out.hlOnCount = document.querySelectorAll('.hl-on').length;
  out.hlOnInHTML = document.body.innerHTML.includes('hl-on');
  const anims = Array.from(document.querySelectorAll('.proj-svg .svg-anim'));
  out.animCount = anims.length;
  out.animNotPaused = anims.filter(e => getComputedStyle(e).animationPlayState !== 'paused')
    .map(e => e.getAttribute('class') + '::' + getComputedStyle(e).animationPlayState);
  return out;
}"""

def check(label, cond):
    print(("PASS" if cond else "FAIL"), label)
    return cond

fails = 0
pw = sync_playwright().start()
browser = pw.chromium.launch()
ctx = browser.new_context(viewport={"width": 1280, "height": 900})

# ---------- a. REST STATE on every page, multiple scroll positions ----------
pages = ["index.html", "research.html", "experience.html", "projects.html", "publications.html", "contact.html"]
pg = ctx.new_page()
for name in pages:
    pg.goto(f"{BASE}/{name}")
    pg.wait_for_timeout(700)
    for frac, label in [(0, "top"), (0.5, "mid"), (1.0, "bottom")]:
        pg.evaluate(f"window.scrollTo(0, document.body.scrollHeight*{frac})")
        pg.wait_for_timeout(900)
        r = pg.evaluate(REST_JS)
        ok = (not r["hlVisible"]) and r["hlOnCount"] == 0 and (not r["hlOnInHTML"]) and (not r["animNotPaused"])
        fails += 0 if check(f"rest {name} [{label}] hl={r['hlCount']} anims={r['animCount']} "
                            f"visible={r['hlVisible']} notPaused={r['animNotPaused']} hlOn={r['hlOnCount']}", ok) else 1
pg.close()

# ---------- b. hover/focus contexts sweep to 100% 84%, leave returns to 0% ----------
def hover_check(page, container_sel, hl_sel, label, shot=None, wait=1300):
    box = page.locator(container_sel).first.bounding_box()
    page.mouse.move(box["x"] + box["width"] / 2, box["y"] + min(box["height"] / 2, 40))
    page.wait_for_timeout(wait)
    sizes = page.eval_on_selector_all(hl_sel, "els => els.map(e => getComputedStyle(e).backgroundSize)")
    ok = len(sizes) > 0 and all(s.startswith("100%") for s in sizes)
    if shot:
        page.screenshot(path=f"{SHOTS}/{shot}")
    # pointer leave
    page.mouse.move(5, 5)
    page.wait_for_timeout(1200)
    sizes2 = page.eval_on_selector_all(hl_sel, "els => els.map(e => getComputedStyle(e).backgroundSize)")
    ok2 = all(s.startswith("0%") for s in sizes2)
    return check(f"hover {label}: swept={sizes}", ok) + check(f"leave {label}: back={sizes2}", ok2) - 1

pg = ctx.new_page()
# index: hero role
pg.goto(f"{BASE}/index.html"); pg.wait_for_timeout(800)
fails += 1 - hover_check(pg, ".hero .role", ".hero .role .hl-g", "index hero role")
# index: about paragraph (first with highlights)
fails += 1 - hover_check(pg, "#about p.lead", "#about p.lead .hl-y, #about p.lead .hl-g, #about p.lead .hl-p, #about p.lead .hl-b",
                         "index about p.lead", shot="index-about-hover.png")
# index: news item (second has hl-p)
pg.evaluate("document.querySelector('#news').scrollIntoView()"); pg.wait_for_timeout(800)
fails += 1 - hover_check(pg, ".news-item >> nth=1", ".news-item >> nth=1 >> css=.hl-p", "index news item")
pg.screenshot(path=f"{SHOTS}/index-news-rest.png")
pg.close()

# research li
pg = ctx.new_page(); pg.goto(f"{BASE}/research.html"); pg.wait_for_timeout(800)
fails += 1 - hover_check(pg, ".interest-list li >> nth=0", ".interest-list li >> nth=0 >> css=.hl-y", "research li 0")
fails += 1 - hover_check(pg, ".interest-list li >> nth=2", ".interest-list li >> nth=2 >> css=.hl-g", "research li 2")
pg.close()

# experience item
pg = ctx.new_page(); pg.goto(f"{BASE}/experience.html"); pg.wait_for_timeout(800)
fails += 1 - hover_check(pg, ".xp-item >> nth=0", ".xp-item >> nth=0 >> css=.hl-g", "experience item 0", shot="experience-hover.png")
pg.close()

# projects card: title + desc sweep + art running
pg = ctx.new_page(); pg.goto(f"{BASE}/projects.html"); pg.wait_for_timeout(900)
pg.screenshot(path=f"{SHOTS}/projects-rest.png", full_page=False)
# rest assertions again here with anims
r = pg.evaluate(REST_JS)
fails += 0 if check(f"projects rest anims paused ({r['animCount']} parts)", not r["animNotPaused"]) else 1
arcs = pg.eval_on_selector_all(".proj-card[data-project='gesture'] .a-arc",
                               "els => els.map(e => getComputedStyle(e).opacity)")
fails += 0 if check(f"gesture arcs invisible at rest: {arcs}", len(arcs) == 3 and all(o == "0" for o in arcs)) else 1

card = ".proj-card[data-project='niro-bot']"
box = pg.locator(card).bounding_box()
pg.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
pg.wait_for_timeout(1400)
title_size = pg.eval_on_selector(f"{card} .card-hl", "e => getComputedStyle(e).backgroundSize")
desc_size = pg.eval_on_selector(f"{card} .proj-desc .hl-y", "e => getComputedStyle(e).backgroundSize")
states = pg.eval_on_selector_all(f"{card} .svg-anim", "els => els.map(e => getComputedStyle(e).animationPlayState)")
fails += 0 if check(f"card hover title swept: {title_size}", title_size.startswith("100%")) else 1
fails += 0 if check(f"card hover desc swept: {desc_size}", desc_size.startswith("100%")) else 1
fails += 0 if check(f"card hover anims running: {states}", len(states) > 0 and all(s == "running" for s in states)) else 1
pg.screenshot(path=f"{SHOTS}/projects-card-hover.png")

# keyboard focus on card also sweeps/runs
pg.mouse.move(5, 5); pg.wait_for_timeout(1100)
pg.locator(card).focus()
pg.wait_for_timeout(1300)
title_size = pg.eval_on_selector(f"{card} .card-hl", "e => getComputedStyle(e).backgroundSize")
states = pg.eval_on_selector_all(f"{card} .svg-anim", "els => els.map(e => getComputedStyle(e).animationPlayState)")
fails += 0 if check(f"card focus-visible title swept: {title_size}", title_size.startswith("100%")) else 1
fails += 0 if check(f"card focus-visible anims running: {states}", all(s == "running" for s in states)) else 1

# ---------- c. modal: cloned SVG present + playing; close -> paused ----------
pg.locator(card).click()
pg.wait_for_timeout(900)
modal_svg = pg.evaluate("""() => {
  const s = document.querySelector('.modal-svg');
  if (!s) return {present:false};
  const states = Array.from(s.querySelectorAll('.svg-anim')).map(e => getComputedStyle(e).animationPlayState);
  return {present:true, cls:s.getAttribute('class'), label:s.getAttribute('aria-label'),
          role:s.getAttribute('role'), states};
}""")
fails += 0 if check(f"modal svg cloned: {modal_svg}", modal_svg.get("present") and "playing" in modal_svg["cls"]
                    and modal_svg["label"] and modal_svg["role"] == "img"
                    and all(x == "running" for x in modal_svg["states"])) else 1
# modal key phrases colored (swept); stagger is up to ~18*80ms + .7s transition
pg.wait_for_timeout(2600)
mhl = pg.eval_on_selector_all(".modal-hl", "els => els.map(e => getComputedStyle(e).backgroundSize)")
fails += 0 if check(f"modal key phrases swept: n={len(mhl)}", len(mhl) > 0 and all(s.startswith("100%") for s in mhl)) else 1
pg.screenshot(path=f"{SHOTS}/modal-open.png")
# close: focus returns to the origin card (documented a11y behavior), so
# :focus-visible legitimately keeps it running; after focus leaves the card
# (and no hover), it must return to paused
pg.keyboard.press("Escape")
pg.wait_for_timeout(700)
states = pg.eval_on_selector_all(f"{card} .svg-anim", "els => els.map(e => getComputedStyle(e).animationPlayState)")
print("INFO after close with returned focus:", states)
pg.evaluate("document.activeElement && document.activeElement.blur()")
pg.mouse.move(5, 5); pg.wait_for_timeout(500)
states = pg.eval_on_selector_all(f"{card} .svg-anim", "els => els.map(e => getComputedStyle(e).animationPlayState)")
fails += 0 if check(f"after modal close + blur card paused: {states}", all(s == "paused" for s in states)) else 1
pg.close()

# ---------- d. reduced motion ----------
ctx2 = browser.new_context(viewport={"width": 1280, "height": 900}, reduced_motion="reduce")
pg = ctx2.new_page()
pg.goto(f"{BASE}/index.html"); pg.wait_for_timeout(600)
box = pg.locator("#about p.lead").bounding_box()
pg.mouse.move(box["x"] + box["width"] / 2, box["y"] + 20)
pg.wait_for_timeout(300)
dur = pg.eval_on_selector("#about p.lead .hl-y", "e => getComputedStyle(e).transitionDuration")
size = pg.eval_on_selector("#about p.lead .hl-y", "e => getComputedStyle(e).backgroundSize")
fails += 0 if check(f"reduced-motion hover instant: duration={dur} size={size}",
                    dur in ("0s", "0s, 0s") and size.startswith("100%")) else 1
pg.goto(f"{BASE}/projects.html"); pg.wait_for_timeout(700)
box = pg.locator(card).bounding_box()
pg.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
pg.wait_for_timeout(800)
names = pg.eval_on_selector_all(f"{card} .svg-anim", "els => els.map(e => getComputedStyle(e).animationName)")
fails += 0 if check(f"reduced-motion anims none: {names}", all(n == "none" for n in names)) else 1
pg.close(); ctx2.close()

# ---------- f. extra screenshots: index about rest ----------
pg = ctx.new_page()
pg.goto(f"{BASE}/index.html"); pg.wait_for_timeout(900)
pg.screenshot(path=f"{SHOTS}/index-about-rest.png")
pg.close()

browser.close(); pw.stop()
print("\nTOTAL FAILURES:", fails)
sys.exit(1 if fails else 0)
