import sys
from playwright.sync_api import sync_playwright

fails = 0
def check(label, cond):
    global fails
    print(("PASS" if cond else "FAIL"), label)
    if not cond: fails += 1

pw = sync_playwright().start()
browser = pw.chromium.launch()
pg = browser.new_context(viewport={"width": 1280, "height": 900}).new_page()
pg.goto("file:///mnt/agents/output/app/projects.html")
pg.wait_for_timeout(900)
r = pg.evaluate("""() => ({
  hlVisible: Array.from(document.querySelectorAll('.hl-y,.hl-g,.hl-p,.hl-b'))
    .filter(e => !getComputedStyle(e).backgroundSize.startsWith('0%')).length,
  notPaused: Array.from(document.querySelectorAll('.proj-svg .svg-anim'))
    .filter(e => getComputedStyle(e).animationPlayState !== 'paused').length,
  bodyVisible: getComputedStyle(document.body).opacity
})""")
check(f"file:// rest: {r}", r["hlVisible"] == 0 and r["notPaused"] == 0 and r["bodyVisible"] == "1")
card = ".proj-card[data-project='aoaver']"
pg.locator(card).hover()
pg.wait_for_timeout(1300)
states = pg.eval_on_selector_all(f"{card} .svg-anim", "els => els.map(e => getComputedStyle(e).animationPlayState)")
check(f"file:// hover running: {states}", all(s == "running" for s in states))
pg.screenshot(path="/mnt/agents/output/shots13/file-projects-hover.png")
pg.locator(card).click()
pg.wait_for_timeout(1000)
ms = pg.evaluate("""() => { const s = document.querySelector('.modal-svg');
  return s ? Array.from(s.querySelectorAll('.svg-anim')).map(e => getComputedStyle(e).animationPlayState) : null; }""")
check(f"file:// modal clone playing: {ms}", ms is not None and all(x == "running" for x in ms))
browser.close(); pw.stop()
print("FAILURES:", fails)
sys.exit(1 if fails else 0)
