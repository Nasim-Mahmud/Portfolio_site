import json
import subprocess
import time
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8614/"
APP = "/mnt/agents/output/app"
SHOTS = "/mnt/agents/output/shots14"
PAGES = ["index.html", "research.html", "experience.html",
         "projects.html", "publications.html", "contact.html"]

subprocess.run(["mkdir", "-p", SHOTS])
server = subprocess.Popen(["python3", "-m", "http.server", "8614",
                           "--bind", "127.0.0.1"], cwd=APP,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)

results = {}
failures = []

def check(name, cond, detail=""):
    results[name] = {"pass": bool(cond), "detail": str(detail)[:300]}
    if not cond:
        failures.append(name)
    print(("PASS " if cond else "FAIL ") + name + " :: " + str(detail)[:200])

# JS helpers -------------------------------------------------------------
HL_SEL = ".hl-y, .hl-g, .hl-p, .hl-b"
JS_HL_STATE = """
(sel) => Array.from(document.querySelectorAll(sel)).map(el => ({
  text: (el.textContent || '').trim().slice(0, 30),
  inDesc: el.closest('.proj-desc') !== null,
  hasHl: el.classList.contains('hl'),
  hasOn: el.classList.contains('hl-on'),
  bg: getComputedStyle(el).backgroundSize,
  top: el.getBoundingClientRect().top,
  vh: window.innerHeight
}))
"""

def hl_state(page):
    return page.evaluate(JS_HL_STATE, HL_SEL)

def non_desc(st):
    return [e for e in st if not e["inDesc"]]

def desc(st):
    return [e for e in st if e["inDesc"]]

def slow_scroll_to_bottom(page, step=420, pause=0.28):
    page.evaluate("() => window.scrollTo(0, 0)")
    time.sleep(0.2)
    height = page.evaluate("() => document.body.scrollHeight")
    y = 0
    while y < height:
        y += step
        page.evaluate("(yy) => window.scrollTo(0, yy)", y)
        time.sleep(pause)
        height = page.evaluate("() => document.body.scrollHeight")
    page.evaluate("() => window.scrollTo(0, document.body.scrollHeight)")
    time.sleep(1.8)  # let stagger delays + .8s transitions finish

try:
    with sync_playwright() as pw:
        browser = pw.chromium.launch()

        # ================= per-page scroll-trigger checks (a, b, e) ======
        for pg in PAGES:
            page = browser.new_page(viewport={"width": 1280, "height": 800})
            page.goto(BASE + pg)
            page.wait_for_timeout(1600)  # entry transition + above-fold sweep
            st = hl_state(page)
            nd = non_desc(st)
            above = [e for e in nd if e["top"] < e["vh"] * 0.92]
            below = [e for e in nd if e["top"] >= e["vh"] * 0.92]
            check(pg + ":a_above_fold_lit",
                  all(e["hasOn"] and e["bg"] == "100% 84%" for e in above),
                  "%d/%d above-fold lit" % (sum(1 for e in above if e["hasOn"]), len(above)))
            check(pg + ":a_below_fold_unlit",
                  all((not e["hasOn"]) and e["bg"] == "0% 84%" for e in below),
                  "%d below-fold, unlit=%d" % (len(below), sum(1 for e in below if not e["hasOn"])))
            check(pg + ":a_hl_class_added",
                  all(e["hasHl"] for e in nd),
                  "hl class on %d/%d" % (sum(1 for e in nd if e["hasHl"]), len(nd)))

            # (b) slow scroll: everything lights and stays lit
            slow_scroll_to_bottom(page)
            st = hl_state(page)
            nd = non_desc(st)
            check(pg + ":b_all_lit_after_scroll",
                  all(e["hasOn"] and e["bg"] == "100% 84%" for e in nd),
                  "%d/%d lit" % (sum(1 for e in nd if e["hasOn"]), len(nd)))
            # scroll back to top: highlights persist
            page.evaluate("() => window.scrollTo(0, 0)")
            page.wait_for_timeout(700)
            st = hl_state(page)
            nd = non_desc(st)
            check(pg + ":b_stay_lit_back_at_top",
                  all(e["hasOn"] and e["bg"] == "100% 84%" for e in nd),
                  "%d/%d still lit" % (sum(1 for e in nd if e["hasOn"]), len(nd)))

            # (e) heading sweeps: all sec-word lit after full scroll
            sec = page.evaluate("""
              () => Array.from(document.querySelectorAll('.sec-head .sec-word'))
                    .map(w => ({on: w.classList.contains('sec-word-on'),
                                bg: getComputedStyle(w).backgroundSize}))
            """)
            check(pg + ":e_heading_sweeps",
                  len(sec) > 0 and all(w["on"] and w["bg"].startswith("100%") for w in sec),
                  "%d/%d sec-words lit" % (sum(1 for w in sec if w["on"]), len(sec)))
            page.close()

        # ================= (c) hover does not trigger non-card highlights =
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(BASE + "index.html")
        page.wait_for_timeout(1500)
        # place the first About <p> in the bottom sliver of the viewport
        # (visible, hoverable, but outside the observer's -8% band)
        page.evaluate("""
          () => {
            const p = document.querySelector('#about p');
            const r = p.getBoundingClientRect();
            window.scrollBy(0, r.top - window.innerHeight * 0.965);
          }
        """)
        page.wait_for_timeout(600)
        st = [e for e in hl_state(page) if not e["inDesc"] and e["top"] > 0]
        visible_unlit = [e for e in st if not e["hasOn"] and e["top"] > e["vh"] * 0.9]
        check("c_setup_about_in_bottom_sliver", len(visible_unlit) > 0,
              json.dumps(visible_unlit[:3]))
        box = page.locator("#about p").first.bounding_box()
        page.mouse.move(box["x"] + box["width"] / 2, box["y"] + min(box["height"] / 2, 20))
        page.wait_for_timeout(1200)
        st2 = [e for e in hl_state(page) if not e["inDesc"] and e["top"] > e["vh"] * 0.9]
        check("c_hover_about_no_change",
              len(st2) > 0 and all(not e["hasOn"] and e["bg"] == "0% 84%" for e in st2),
              json.dumps(st2[:3]))
        # now scroll it into the trigger band: it must light and stay lit
        page.evaluate("() => window.scrollBy(0, window.innerHeight * 0.15)")
        page.wait_for_timeout(1600)
        st3 = hl_state(page)
        about_lit = [e for e in non_desc(st3) if e["hasOn"]]
        check("c_scroll_lights_about", len(about_lit) >= 4,
              "%d about phrases lit after scroll" % len(about_lit))
        page.close()

        # research.html: all 4 interest highlights are above the fold, so
        # they are lit on entry; hovering an <li> must change NOTHING
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(BASE + "research.html")
        page.wait_for_timeout(1500)
        before = hl_state(page)
        box = page.locator(".interest-list li").first.bounding_box()
        page.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
        page.wait_for_timeout(1200)
        after = hl_state(page)
        same = all(b["hasOn"] == a["hasOn"] and b["bg"] == a["bg"]
                   for b, a in zip(before, after))
        check("c_hover_noop_research.html",
              same and all(e["hasOn"] and e["bg"] == "100% 84%" for e in after),
              "identical state during hover: %s" % same)
        page.close()

        # experience.html: place an unlit .xp-item in the bottom sliver and hover
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(BASE + "experience.html")
        page.wait_for_timeout(1200)
        page.evaluate("""
          () => {
            const els = Array.from(document.querySelectorAll('.xp-item'));
            const el = els[els.length - 1];
            const r = el.getBoundingClientRect();
            window.scrollBy(0, r.top - window.innerHeight * 0.96);
          }
        """)
        page.wait_for_timeout(600)
        before = [e for e in hl_state(page) if not e["inDesc"] and e["top"] > e["vh"] * 0.9]
        box = page.locator(".xp-item").last.bounding_box()
        page.mouse.move(box["x"] + box["width"] / 2, box["y"] + min(box["height"] / 2, 15))
        page.wait_for_timeout(1200)
        after = [e for e in hl_state(page) if not e["inDesc"] and e["top"] > e["vh"] * 0.9]
        check("c_hover_noop_experience.html",
              len(after) > 0 and all(not e["hasOn"] for e in after) and
              len(before) == len(after),
              "before=%s after=%s" % (json.dumps(before[:2]), json.dumps(after[:2])))
        page.close()

        # ================= (d) projects.html card interactions ===========
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(BASE + "projects.html")
        page.wait_for_timeout(1500)

        # initHighlights must not touch proj-desc keywords
        st = hl_state(page)
        d = desc(st)
        check("d_desc_keywords_excluded_from_js",
              len(d) > 0 and all(not e["hasHl"] and not e["hasOn"] for e in d),
              "%d desc keywords, hl-class on %d" % (len(d), sum(1 for e in d if e["hasHl"])))

        # card at rest: scroll first card into view
        page.evaluate("() => document.querySelector('.proj-card').scrollIntoView({block: 'center'})")
        page.wait_for_timeout(900)
        rest = page.evaluate("""
          () => {
            const card = document.querySelector('.proj-card');
            const kw = card.querySelector('.proj-desc .hl-y, .proj-desc .hl-g, .proj-desc .hl-p, .proj-desc .hl-b');
            const title = card.querySelector('.card-hl');
            const anim = card.querySelector('.svg-anim');
            return {
              kwBg: kw ? getComputedStyle(kw).backgroundSize : null,
              titleBg: title ? getComputedStyle(title).backgroundSize : null,
              animState: anim ? getComputedStyle(anim).animationPlayState : null
            };
          }
        """)
        check("d_card_at_rest", rest["kwBg"] == "0% 84%" and rest["titleBg"] == "0% 84%"
              and rest["animState"] == "paused", json.dumps(rest))
        page.screenshot(path=SHOTS + "/projects-card-rest.png")

        # hover the card
        box = page.locator(".proj-card").first.bounding_box()
        page.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
        page.wait_for_timeout(1300)
        hov = page.evaluate("""
          () => {
            const card = document.querySelector('.proj-card');
            const kw = card.querySelector('.proj-desc .hl-y, .proj-desc .hl-g, .proj-desc .hl-p, .proj-desc .hl-b');
            const title = card.querySelector('.card-hl');
            const anim = card.querySelector('.svg-anim');
            return {
              kwBg: kw ? getComputedStyle(kw).backgroundSize : null,
              titleBg: title ? getComputedStyle(title).backgroundSize : null,
              animState: anim ? getComputedStyle(anim).animationPlayState : null
            };
          }
        """)
        check("d_card_hover_sweeps", hov["kwBg"] == "100% 84%" and hov["titleBg"] == "100% 84%"
              and hov["animState"] == "running", json.dumps(hov))
        page.screenshot(path=SHOTS + "/projects-card-hover.png")

        # leave: reverts
        page.mouse.move(10, 10)
        page.wait_for_timeout(1300)
        left = page.evaluate("""
          () => {
            const card = document.querySelector('.proj-card');
            const kw = card.querySelector('.proj-desc .hl-y, .proj-desc .hl-g, .proj-desc .hl-p, .proj-desc .hl-b');
            const title = card.querySelector('.card-hl');
            const anim = card.querySelector('.svg-anim');
            return {
              kwBg: kw ? getComputedStyle(kw).backgroundSize : null,
              titleBg: title ? getComputedStyle(title).backgroundSize : null,
              animState: anim ? getComputedStyle(anim).animationPlayState : null
            };
          }
        """)
        check("d_card_leave_reverts", left["kwBg"] == "0% 84%" and left["titleBg"] == "0% 84%"
              and left["animState"] == "paused", json.dumps(left))

        # open the modal (13 key phrases + 5 sub-heads, staggered 80ms:
        # last sweep starts ~1.4s in, transition .8s, so wait 3.2s)
        page.locator(".proj-card").first.click()
        page.wait_for_timeout(3200)
        modal = page.evaluate("""
          () => {
            const m = document.querySelector('#projectModal');
            const svg = m.querySelector('svg.modal-svg.playing');
            const anim = svg ? svg.querySelector('.svg-anim') : null;
            const phrases = Array.from(m.querySelectorAll('.modal-hl'));
            const subs = Array.from(m.querySelectorAll('.modal-sweep-on'));
            return {
              open: m.classList.contains('open') || getComputedStyle(m).visibility === 'visible',
              svgPlaying: !!svg,
              animState: anim ? getComputedStyle(anim).animationPlayState : null,
              phrasesLit: phrases.filter(p => p.classList.contains('modal-hl-on') &&
                            getComputedStyle(p).backgroundSize.startsWith('100%')).length,
              phrasesTotal: phrases.length,
              subHeadsLit: subs.length
            };
          }
        """)
        check("d_modal_open", modal["open"] and modal["svgPlaying"]
              and modal["animState"] == "running"
              and modal["phrasesLit"] > 0 and modal["phrasesLit"] == modal["phrasesTotal"]
              and modal["subHeadsLit"] > 0, json.dumps(modal))
        page.screenshot(path=SHOTS + "/projects-modal-open.png")
        page.keyboard.press("Escape")
        page.wait_for_timeout(600)
        page.close()

        # ================= (e) reduced motion ============================
        ctx = browser.new_context(viewport={"width": 1280, "height": 800},
                                  reduced_motion="reduce")
        page = ctx.new_page()
        page.goto(BASE + "index.html")
        page.wait_for_timeout(900)
        st = hl_state(page)
        nd = non_desc(st)
        check("e_reduced_motion_instant_all",
              len(nd) > 0 and all(e["hasOn"] for e in nd),
              "%d/%d hl-on immediately" % (sum(1 for e in nd if e["hasOn"]), len(nd)))
        rm = page.evaluate("""
          () => {
            const el = document.querySelector('.hl-y.hl');
            const anim = document.querySelector('.svg-anim');
            return {
              dur: el ? getComputedStyle(el).transitionDuration : null,
              bg: el ? getComputedStyle(el).backgroundSize : null,
              animName: anim ? getComputedStyle(anim).animationName : null
            };
          }
        """)
        check("e_reduced_motion_0s_and_no_svg",
              rm["dur"] == "0s" and rm["bg"] == "100% 84%" and rm["animName"] == "none",
              json.dumps(rm))
        # hover a card under reduced motion: art stays still
        page.goto(BASE + "projects.html")
        page.wait_for_timeout(800)
        page.evaluate("() => document.querySelector('.proj-card').scrollIntoView({block: 'center'})")
        box = page.locator(".proj-card").first.bounding_box()
        page.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)
        page.wait_for_timeout(900)
        rm2 = page.evaluate("""
          () => {
            const anim = document.querySelector('.proj-card .svg-anim');
            return { name: getComputedStyle(anim).animationName,
                     state: getComputedStyle(anim).animationPlayState };
          }
        """)
        check("e_reduced_motion_card_art_still", rm2["name"] == "none", json.dumps(rm2))
        ctx.close()

        # ================= file:// smoke test ============================
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto("file://" + APP + "/index.html")
        page.wait_for_timeout(1600)
        st = hl_state(page)
        nd = non_desc(st)
        above = [e for e in nd if e["top"] < e["vh"] * 0.92]
        check("file_above_fold_lit", len(above) > 0 and all(e["hasOn"] for e in above),
              "%d above-fold lit over file://" % len(above))
        slow_scroll_to_bottom(page)
        st = hl_state(page)
        nd = non_desc(st)
        check("file_all_lit_after_scroll", all(e["hasOn"] for e in nd),
              "%d/%d lit over file://" % (sum(1 for e in nd if e["hasOn"]), len(nd)))
        page.close()

        # ================= (g) screenshots ===============================
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(BASE + "index.html")
        page.wait_for_timeout(1400)
        page.screenshot(path=SHOTS + "/index-top-rest.png")
        page.evaluate("() => document.querySelector('#about').scrollIntoView()")
        page.wait_for_timeout(1800)
        page.screenshot(path=SHOTS + "/index-about-lit.png")
        page.close()

        for pg, shot in [("research.html", "research-scrolled-lit.png"),
                         ("experience.html", "experience-scrolled-lit.png")]:
            page = browser.new_page(viewport={"width": 1280, "height": 800})
            page.goto(BASE + pg)
            page.wait_for_timeout(1200)
            slow_scroll_to_bottom(page, step=500, pause=0.22)
            page.evaluate("() => window.scrollTo(0, 300)")
            page.wait_for_timeout(900)
            page.screenshot(path=SHOTS + "/" + shot)
            page.close()

        browser.close()
finally:
    server.terminate()

print("\n==== SUMMARY ====")
print(json.dumps(results, indent=1))
print("FAILURES:", failures if failures else "none")
