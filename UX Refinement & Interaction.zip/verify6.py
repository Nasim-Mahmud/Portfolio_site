import json
import subprocess
import time
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8613/index.html"
SHOTS = "/mnt/agents/output/shots6"

server = subprocess.Popen(
    ["python3", "-m", "http.server", "8613", "--bind", "127.0.0.1"],
    cwd="/mnt/agents/output/app",
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)
time.sleep(1.0)

results = {}

def phrase_report(page):
    return page.evaluate(
        """() => Array.from(document.querySelectorAll('#about b, #about strong')).map(el => ({
            text: el.textContent.trim().slice(0, 40),
            cls: el.className,
            weight: getComputedStyle(el).fontWeight,
            delay: getComputedStyle(el).transitionDelay,
            dur: getComputedStyle(el).transitionDuration,
            bgSize: getComputedStyle(el).backgroundSize,
        }))"""
    )

try:
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path="/usr/bin/chromium",
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )

        # ---------- LIGHT THEME ----------
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        page.goto(BASE, wait_until="networkidle")
        page.wait_for_timeout(600)  # page entry + hero stagger

        # early-sweep capture: scroll about into view, shoot ~200ms in
        page.evaluate("document.querySelector('#about').scrollIntoView({block:'center'})")
        page.wait_for_timeout(200)
        page.screenshot(path=f"{SHOTS}/about-light-mid-sweep.png")
        mid = phrase_report(page)

        page.wait_for_timeout(1200)
        page.screenshot(path=f"{SHOTS}/about-light.png")
        results["light"] = phrase_report(page)

        # ---------- DARK THEME ----------
        page2 = browser.new_page(viewport={"width": 1280, "height": 800})
        page2.add_init_script("try{localStorage.setItem('portfolio-theme','dark')}catch(e){}")
        page2.goto(BASE, wait_until="networkidle")
        page2.wait_for_timeout(600)
        page2.evaluate("document.querySelector('#about').scrollIntoView({block:'center'})")
        page2.wait_for_timeout(1400)
        page2.screenshot(path=f"{SHOTS}/about-dark.png")
        results["dark"] = phrase_report(page2)
        # sampled highlight color on the first phrase
        results["dark_hl"] = page2.evaluate(
            "getComputedStyle(document.querySelector('#about b.hl')).backgroundImage.slice(0,80)"
        )

        # ---------- REDUCED MOTION ----------
        page3 = browser.new_page(
            viewport={"width": 1280, "height": 800}, reduced_motion="reduce"
        )
        page3.goto(BASE, wait_until="networkidle")
        page3.wait_for_timeout(300)
        results["reduced_before_scroll"] = phrase_report(page3)
        page3.evaluate("document.querySelector('#about').scrollIntoView({block:'center'})")
        page3.wait_for_timeout(200)
        page3.screenshot(path=f"{SHOTS}/about-reduced-motion.png")
        results["reduced"] = phrase_report(page3)

        # ---------- hero stagger still works / other pages untouched ----------
        results["hero_stagger_cleanup"] = page.evaluate(
            "document.querySelectorAll('.hero-stagger').length"
        )
        page4 = browser.new_page(viewport={"width": 1280, "height": 800})
        page4.goto(BASE.replace("index.html", "research.html"), wait_until="networkidle")
        page4.wait_for_timeout(400)
        results["research_b"] = page4.evaluate(
            """() => Array.from(document.querySelectorAll('b, strong')).map(el => ({
                cls: el.className, weight: getComputedStyle(el).fontWeight }))"""
        )

        browser.close()
finally:
    server.terminate()

print(json.dumps(results, indent=1))
