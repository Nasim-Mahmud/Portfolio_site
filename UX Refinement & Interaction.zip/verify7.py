import json
import subprocess
import time
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8615/"
SHOTS = "/mnt/agents/output/shots7"

server = subprocess.Popen(
    ["python3", "-m", "http.server", "8615", "--bind", "127.0.0.1"],
    cwd="/mnt/agents/output/app", stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
)
time.sleep(1.0)
results = {}
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path="/usr/bin/chromium",
                                    args=["--no-sandbox", "--disable-dev-shm-usage"])

        # ---------- HOME: about -> featured projects flow ----------
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        page.goto(BASE + "index.html", wait_until="networkidle")
        page.wait_for_timeout(700)
        results["home_sections"] = page.evaluate(
            "Array.from(document.querySelectorAll('main section .sec-head')).map(h => h.textContent.trim())"
        )
        results["home_skill_refs"] = page.evaluate(
            "document.querySelectorAll('.skill-row, .skill-key, .skill-val, #skills').length"
        )
        results["about_highlights"] = page.evaluate(
            """() => Array.from(document.querySelectorAll('#about b')).map(el => ({
                text: el.textContent.trim().slice(0, 28), cls: el.className,
                weight: getComputedStyle(el).fontWeight }))"""
        )
        # scroll: about fully in view (new sentence visible), highlights fire
        page.evaluate("document.querySelector('#about').scrollIntoView({block:'center'})")
        page.wait_for_timeout(1400)
        page.screenshot(path=f"{SHOTS}/home-about-no-skills.png")
        results["about_highlights_after"] = page.evaluate(
            "Array.from(document.querySelectorAll('#about b')).map(el => el.className)"
        )
        # scroll to featured projects (should directly follow about)
        page.evaluate("document.querySelector('#featured-projects').scrollIntoView({block:'start'})")
        page.wait_for_timeout(900)
        page.screenshot(path=f"{SHOTS}/home-featured-after-about.png")

        # ---------- EXPERIENCE: light + dark ----------
        page2 = browser.new_page(viewport={"width": 1280, "height": 1000})
        page2.goto(BASE + "experience.html", wait_until="networkidle")
        page2.wait_for_timeout(800)
        page2.evaluate("window.scrollTo(0, 0)")
        page2.wait_for_timeout(400)
        page2.screenshot(path=f"{SHOTS}/experience-light.png", full_page=True)
        results["xp_tags"] = page2.evaluate(
            """() => Array.from(document.querySelectorAll('.xp-item')).map(item => ({
                role: item.querySelector('.xp-role').textContent,
                tags: Array.from(item.querySelectorAll('.xp-tags .tag')).map(t => t.textContent),
                tagColor: item.querySelector('.xp-tags .tag') ? getComputedStyle(item.querySelector('.xp-tags .tag')).color : null }))"""
        )

        page3 = browser.new_page(viewport={"width": 1280, "height": 1000})
        page3.add_init_script("try{localStorage.setItem('portfolio-theme','dark')}catch(e){}")
        page3.goto(BASE + "experience.html", wait_until="networkidle")
        page3.wait_for_timeout(800)
        page3.screenshot(path=f"{SHOTS}/experience-dark.png", full_page=True)

        # ---------- nav/transition sanity: click nav link from home ----------
        results["nav_active_exp"] = page2.evaluate(
            "document.querySelector('.nav-links a.active') ? document.querySelector('.nav-links a.active').getAttribute('href') : null"
        )
        results["page_in"] = page2.evaluate("document.body.classList.contains('page-in')")

        browser.close()
finally:
    server.terminate()

print(json.dumps(results, indent=1))
