import json
import re
import subprocess
import time
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8616/"
APP = "/mnt/agents/output/app"
SHOTS = "/mnt/agents/output/shots9"

results = {}
failures = []

def check(name, cond, detail=""):
    results[name] = {"pass": bool(cond), "detail": detail}
    if not cond:
        failures.append(name)

# ---------------- (f) static palette checks: hues + contrast ----------------
ts = open(APP + "/scripts/main.ts").read()
block = ts[ts.index("HIGHLIGHT_PALETTES"):ts.index("const ANIMATION_MS")]
rgba = re.findall(r"rgba\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)", block)

def hue(r, g, b):
    r, g, b = r/255, g/255, b/255
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    if d == 0:
        return 0.0
    if mx == r:
        h = ((g - b) / d) % 6
    elif mx == g:
        h = (b - r) / d + 2
    else:
        h = (r - g) / d + 4
    return h * 60

hues = [round(hue(int(r), int(g), int(b)), 1) for r, g, b, a in rgba]
pinks = [h for h in hues if 295 <= h <= 345]
check("f_no_pink_hues", len(pinks) == 0 and len(rgba) == 48,
      f"{len(rgba)} rgba colors parsed (expect 48 = 4 palettes x 3 sets x 4 colors); hues={hues}; pink-band hits={pinks}")

def lum(r, g, b):
    def ch(c):
        c = c / 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)

def contrast(l1, l2):
    lo, hi = min(l1, l2), max(l1, l2)
    return (hi + 0.05) / (lo + 0.05)

# parse palettes structured
pal_names = re.findall(r'name: "(\w+)"', block)
colors = [(int(r), int(g), int(b), float(a)) for r, g, b, a in rgba]
# order: for each palette: light(4), dark(4), darkGlow(4)
worst = []
for i, name in enumerate(pal_names):
    light = colors[i*12:i*12+4]
    dark = colors[i*12+4:i*12+8]
    for (r, g, b, a) in light:
        br, bg, bb = 250, 249, 246  # --bg light
        er, eg, eb = r*a+br*(1-a), g*a+bg*(1-a), b*a+bb*(1-a)
        c = contrast(lum(er, eg, eb), lum(0x1c, 0x19, 0x17))  # --ink light
        worst.append((round(c, 2), name, "light", (r, g, b, a)))
    for (r, g, b, a) in dark:
        br, bg, bb = 22, 21, 19  # --bg dark
        er, eg, eb = r*a+br*(1-a), g*a+bg*(1-a), b*a+bb*(1-a)
        c = contrast(lum(er, eg, eb), lum(0xe7, 0xe3, 0xdd))  # --ink dark
        worst.append((round(c, 2), name, "dark", (r, g, b, a)))
worst.sort()
check("f_contrast_min_3", worst[0][0] >= 3.0,
      f"worst 5 contrasts (vs body ink, over page bg): {worst[:5]}")

# ---------------- browser assertions ----------------
server = subprocess.Popen(
    ["python3", "-m", "http.server", "8616", "--bind", "127.0.0.1"],
    cwd=APP, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
)
time.sleep(1.0)
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path="/usr/bin/chromium",
                                    args=["--no-sandbox", "--disable-dev-shm-usage"])

        # (a) three fresh loads in the SAME tab (sessionStorage persists)
        page = browser.new_page(viewport={"width": 1280, "height": 900})
        applied = []
        for _ in range(3):
            page.goto(BASE + "index.html", wait_until="load")
            page.wait_for_timeout(250)
            applied.append(page.evaluate(
                "document.documentElement.style.getPropertyValue('--hl-y-light')"))
        distinct = len(set(applied))
        repeats = any(applied[i] == applied[i+1] for i in range(len(applied)-1))
        check("a_3_loads_applied_hly", all(v.strip() for v in applied), str(applied))
        check("a_at_least_2_distinct", distinct >= 2, f"distinct={distinct} {applied}")
        check("a_no_immediate_repeat", not repeats, str(applied))

        # (b) dark vs light highlight backgrounds + glow on .hl-on
        def about_state(pg):
            pg.evaluate("document.querySelector('#about').scrollIntoView({block:'center'})")
            pg.wait_for_timeout(1400)
            return pg.evaluate("""() => {
                const el = document.querySelector('#about b.hl-on');
                const cs = getComputedStyle(el);
                return { bg: cs.backgroundImage, shadow: cs.boxShadow,
                         bgsize: cs.backgroundSize };
            }""")
        light_state = about_state(page)
        page.screenshot(path=f"{SHOTS}/about-light.png")

        page.evaluate("localStorage.setItem('portfolio-theme','dark')")
        page.goto(BASE + "index.html", wait_until="load")
        page.wait_for_timeout(300)
        dark_state = about_state(page)
        page.screenshot(path=f"{SHOTS}/about-dark.png")
        check("b_dark_bg_differs", light_state["bg"] != dark_state["bg"],
              f"light={light_state['bg'][:80]} dark={dark_state['bg'][:80]}")
        sh = dark_state["shadow"]
        glow_ok = sh != "none" and not re.search(r"rgba?\([^)]*,\s*0(\.0+)?\)", sh.split(") ")[0] + ")")
        check("b_dark_glow_present", sh != "none" and "0px 0px 15px 2px" in sh,
              f"dark hl-on box-shadow: {sh}")
        check("b_light_glow_transparent", "rgba(0, 0, 0, 0)" in light_state["shadow"] or light_state["shadow"] == "none",
              f"light hl-on box-shadow: {light_state['shadow']}")
        # heading glow in dark too
        hd = page.evaluate("""() => {
            const el = document.querySelector('.sec-word.sec-word-on');
            return el ? getComputedStyle(el).boxShadow : 'MISSING';
        }""")
        check("b_dark_heading_glow", "0px 0px 17px 2px" in hd, f"sec-word-on shadow: {hd}")

        # (c) all four index headings end with .sec-word-on after scrolling
        for sid, shot in [("#featured-projects", "home-headings-featured.png"),
                          ("#news", "home-headings-news.png"),
                          ("#get-in-touch", "home-headings-touch.png")]:
            page.evaluate(f"document.querySelector('{sid}').scrollIntoView({{block:'start'}})")
            page.wait_for_timeout(1100)
            page.screenshot(path=f"{SHOTS}/{shot}")
        page.evaluate("document.querySelector('#about').scrollIntoView({block:'start'})")
        page.wait_for_timeout(600)
        page.screenshot(path=f"{SHOTS}/home-headings-about.png")
        on_count = page.evaluate("document.querySelectorAll('main .sec-word.sec-word-on').length")
        total = page.evaluate("document.querySelectorAll('main .sec-word').length")
        check("c_index_4_headings", on_count == 4 and total == 4, f"on={on_count} total={total}")

        # (d) card hover + modal-open retention (light mode, fresh page)
        page.evaluate("localStorage.setItem('portfolio-theme','light')")
        page.goto(BASE + "index.html", wait_until="load")
        page.evaluate("document.querySelector('#featured-projects').scrollIntoView({block:'start'})")
        page.wait_for_timeout(900)
        card = page.locator(".proj-card").first
        card.hover()
        page.wait_for_timeout(700)
        hov = page.evaluate("getComputedStyle(document.querySelector('.proj-card .card-hl')).backgroundSize")
        page.screenshot(path=f"{SHOTS}/card-hover-light.png")
        check("d_hover_sweeps", hov.startswith("100%"), f"hover background-size: {hov}")
        card.click()
        page.wait_for_timeout(500)
        page.mouse.move(5, 5)  # move pointer away; modal focus holds the blur
        page.wait_for_timeout(600)
        modal_bg = page.evaluate("""() => {
            const c = document.querySelector('.proj-card');
            return { cls: c.className, bg: getComputedStyle(c.querySelector('.card-hl')).backgroundSize,
                     modalOpen: !document.getElementById('projectModalBackdrop').hidden };
        }""")
        check("d_modal_keeps_highlight", modal_bg["modalOpen"] and "card-open" in modal_bg["cls"] and modal_bg["bg"].startswith("100%"),
              str(modal_bg))
        page.click("#modalClose")
        page.wait_for_timeout(600)
        closed = page.evaluate("""() => ({
            cls: document.querySelector('.proj-card').className,
            bg: getComputedStyle(document.querySelector('.proj-card .card-hl')).backgroundSize,
            hidden: document.getElementById('projectModalBackdrop').hidden })""")
        check("d_close_reverts", closed["hidden"] and "card-open" not in closed["cls"] and closed["bg"].startswith("0%"),
              str(closed))
        # keyboard focus sweep: press Tab first so Chromium's focus-visible
        # heuristic treats the following programmatic focus as keyboard focus
        page.keyboard.press("Tab")
        page.evaluate("document.querySelector('.proj-card').focus()")
        page.wait_for_timeout(700)
        kb = page.evaluate("getComputedStyle(document.querySelector('.proj-card .card-hl')).backgroundSize")
        check("d_focus_sweeps", kb.startswith("100%"), f"focus background-size: {kb}")
        # projects.html card count
        page.goto(BASE + "projects.html", wait_until="load")
        n = page.evaluate("document.querySelectorAll('.proj-title .card-hl').length")
        check("d_projects_5_cardhl", n == 5, f"card-hl on projects.html: {n}")

        # dark hover screenshot
        page.evaluate("localStorage.setItem('portfolio-theme','dark')")
        page.goto(BASE + "index.html", wait_until="load")
        page.evaluate("document.querySelector('#featured-projects').scrollIntoView({block:'start'})")
        page.wait_for_timeout(900)
        page.locator(".proj-card").first.hover()
        page.wait_for_timeout(700)
        page.screenshot(path=f"{SHOTS}/card-hover-dark.png")

        # other pages: exactly one .sec-word-on each
        others = {}
        for pg_name in ["research", "experience", "projects", "publications", "contact"]:
            page.evaluate("localStorage.setItem('portfolio-theme','light')")
            page.goto(BASE + pg_name + ".html", wait_until="load")
            page.wait_for_timeout(700)
            others[pg_name] = page.evaluate("document.querySelectorAll('.sec-word.sec-word-on').length")
        check("c_other_pages_1_heading", all(v == 1 for v in others.values()), str(others))

        # (e) reduced motion: instant application
        ctx = browser.new_context(reduced_motion="reduce", viewport={"width": 1280, "height": 900})
        rp = ctx.new_page()
        rp.goto(BASE + "index.html", wait_until="load")
        rp.wait_for_timeout(150)
        rm = rp.evaluate("""() => ({
            secWordsOn: document.querySelectorAll('.sec-word.sec-word-on').length,
            hlOn: document.querySelectorAll('#about b.hl-on').length,
            hlTotal: document.querySelectorAll('#about b.hl').length,
            cardHlDur: getComputedStyle(document.querySelector('.card-hl')).transitionDuration,
            secWordDur: getComputedStyle(document.querySelector('.sec-word')).transitionDuration })""")
        check("e_reduced_motion_instant", rm["secWordsOn"] == 4 and rm["hlOn"] == rm["hlTotal"] > 0
              and rm["cardHlDur"] == "0s" and rm["secWordDur"] == "0s", str(rm))
        ctx.close()

        # file:// smoke test (palette applies, no crash)
        fp = browser.new_page()
        fp.goto("file://" + APP + "/index.html", wait_until="load")
        fp.wait_for_timeout(300)
        fv = fp.evaluate("document.documentElement.style.getPropertyValue('--hl-y-light')")
        check("file_protocol_palette", bool(fv.strip()), f"file:// --hl-y-light: {fv!r}")
        fp.close()

        browser.close()
finally:
    server.terminate()

print(json.dumps(results, indent=2))
print("FAILURES:", failures if failures else "none")
